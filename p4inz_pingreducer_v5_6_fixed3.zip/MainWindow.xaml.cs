using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.Win32;

namespace ExitLag
{
    public partial class MainWindow : Window
    {
        // ─── REGION DATA ──────────────────────────────────────────────
        private record RegionInfo(string Id, string Name, string Flag, string Sub, string PingIp);
        private static readonly List<RegionInfo> Regions = new()
        {
            new("US",   "United States", "🌎", "US East / West",    "8.8.8.8"),
            new("EU",   "Europe",        "🌍", "EU West / Central", "8.8.4.4"),
            new("ASIA", "Asia Pacific",  "🌏", "SEA / East Asia",   "1.1.1.1"),
            new("BR",   "Brazil",        "🌎", "South America",     "200.160.0.1"),
            new("AU",   "Australia",     "🌏", "Oceania",           "1.0.0.1"),
        };

        // ─── GAME PROFILES ────────────────────────────────────────────
        private record GameProfile(string Name, string Emoji, string BestRegion, string Dns, string Tip);
        private static readonly List<GameProfile> Games = new()
        {
            // ── TIER 1: India/SEA Dominant ────────────────────────────
            new("Free Fire",               "🔥", "ASIA", "1.1.1.1", "Garena — Asia Pacific primary. Best in SEA. Indonesia/PH hub."),
            new("BGMI",                    "🎯", "ASIA", "8.8.8.8", "Battlegrounds Mobile India — KRAFTON India servers. Use Asia Pacific."),
            new("Mobile Legends",          "🔵", "ASIA", "1.1.1.1", "Moonton — Asia Pacific servers. Manila & Singapore hub."),
            new("Honor of Kings",          "👑", "ASIA", "1.1.1.1", "Tencent — SEA launch. Singapore servers are fastest for SEA."),
            new("Wild Rift",               "⚔️", "ASIA", "1.1.1.1", "Riot Games — Asia Pacific hub. Singapore primary for SEA."),
            new("Clash of Clans",          "🏰", "ASIA", "8.8.8.8", "Supercell — Singapore CDN. Asia Pacific cuts latency by 30%."),
            new("Clash Royale",            "👑", "ASIA", "8.8.8.8", "Supercell — Same Singapore CDN as Clash of Clans."),
            new("Genshin Impact",          "⭐", "ASIA", "1.1.1.1", "miHoYo — Asia server in Singapore/HK. Best for India/SEA players."),
            new("PUBG Mobile",             "🟫", "ASIA", "8.8.8.8", "PUBG Corp — Asia servers cover India + SEA. Lowest loss via AP."),
            new("COD Mobile",              "💀", "ASIA", "1.1.1.1", "Activision — Asia Pacific nodes for mobile. India servers online."),
            // ── TIER 2: Global Hits ───────────────────────────────────
            new("Valorant",                "🔴", "US",   "1.1.1.1", "Riot Games — US East primary NA hub. EU for European players."),
            new("CS2",                     "🟠", "EU",   "1.1.1.1", "Valve — EU West has lowest global latency for CS2."),
            new("Fortnite",                "🟦", "US",   "8.8.8.8", "Epic Games — US servers handle most global traffic."),
            new("League of Legends",       "🟡", "US",   "8.8.8.8", "Riot Games NA — US East is primary hub. EU for Europe."),
            new("Apex Legends",            "🟣", "US",   "1.1.1.1", "EA servers — US West best uptime. Asia Pacific for SEA."),
            new("GTA V / FiveM",           "🟢", "US",   "8.8.8.8", "Rockstar / FiveM community servers — US Central."),
            new("Minecraft",               "⬜", "US",   "9.9.9.9", "Hypixel and major servers run US East. Asia for SEA."),
            new("Roblox / Blox Fruits",    "🟥", "US",   "1.1.1.1", "US servers best for Roblox. Cloudflare DNS cuts spike rate."),
            new("Call of Duty (PC/XBOX)",  "🔶", "US",   "1.1.1.1", "Activision — US servers are primary for all modes."),
            new("Overwatch 2",             "🎯", "US",   "1.1.1.1", "Blizzard — US Central primary. EU for European players."),
            new("Dota 2",                  "🌀", "EU",   "8.8.8.8", "Valve — EU West + US East. Perfect Perf Mode + lowest tick."),
            // ── TIER 3: SEA Rising ────────────────────────────────────
            new("Stumble Guys",            "🎪", "ASIA", "1.1.1.1", "Scopely — Asia Pacific CDN. SEA players get best ping here."),
            new("Arena of Valor",          "⚡", "ASIA", "1.1.1.1", "Tencent — Thailand/VN primary. Asia Pacific is best region."),
            new("Ragnarok Origin",         "🏹", "ASIA", "8.8.8.8", "Gravity — PH/TH servers. Asia Pacific always fastest."),
            new("Point Blank",             "🎮", "ASIA", "1.1.1.1", "Garena SEA — Indonesia/PH hosted. Asia Pacific optimal."),
            new("Undawn",                  "🌿", "ASIA", "1.1.1.1", "Garena/Tencent — SEA servers. Asia Pacific primary."),
            new("Asphalt 9",               "🏎️", "ASIA", "1.1.1.1", "Gameloft — Asia CDN for India/SEA. Google DNS cuts jitter."),
            new("Among Us",                "🟣", "US",   "1.1.1.1", "Innersloth — US East primary. Low bandwidth game, DNS matters."),
            new("FIFA Mobile / EA FC",     "⚽", "EU",   "8.8.8.8", "EA — EU West primary for FIFA Mobile. Asia Pacific for SEA."),
            new("Diablo Immortal",         "😈", "ASIA", "1.1.1.1", "Blizzard — Asia server covers India+SEA perfectly."),
            new("New State Mobile",        "🎖️", "ASIA", "8.8.8.8", "KRAFTON — Asia Pacific for India/SEA. Same servers as BGMI."),
            new("Cyber Hunter",            "🤖", "ASIA", "1.1.1.1", "NetEase — Asia Pacific primary for SEA market."),
        };

        // ─── STATE ────────────────────────────────────────────────────
        private readonly KeyResult?  _licence;
        private readonly GuestData?  _guest;
        private readonly bool        _isGuest;
        private readonly Dictionary<string, int>       _regionPings = new();
        private readonly Dictionary<string, TextBlock> _pingLabels  = new();
        private readonly Dictionary<string, Button>    _regionBtns  = new();
        private string?      _selectedRegion  = null;
        private string?      _connectedRegion = null;
        private GameProfile? _selectedGame    = null;
        private bool         _fpsBoostOn      = false;

        // Ping history
        private readonly List<int>   _history       = new();
        private readonly List<int>   _jitterSamples = new();
        private readonly Queue<bool> _lossWindow    = new();
        private const int MaxHist    = 24;
        private const int MaxJitter  = 8;
        private const int LossWindow = 20;

        // Session stats
        private int      _sessionBest  = int.MaxValue;
        private int      _sessionWorst = 0;
        private int      _beforePing   = -1;
        private DateTime _sessionStart;

        // DNS
        private string _activeDns = "1.1.1.1";

        // Optimization mode
        private OptMode _optMode = OptMode.None;

        // Settings
        private bool _spikeAlertEnabled  = false;
        private int  _spikeThreshold     = 200;
        private bool _autoReconnectEnabled = false;
        private bool _startupEnabled      = false;
        private bool _streamerMode        = false;
        private bool _neonEdgeOn          = false;
        private int  _consecutiveFails    = 0;
        private const int MaxConsecutiveFails = 4;

        // Timers
        private readonly DispatcherTimer _pingTimer    = new();
        private readonly DispatcherTimer _expiryTimer  = new();
        private readonly DispatcherTimer _sessionTimer = new();

        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

        public MainWindow(KeyResult? licence, GuestData? guest)
        {
            InitializeComponent();
            _licence = licence;
            _guest   = guest;
            _isGuest = guest != null;
            Loaded  += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            BuildRegionButtons();
            BuildGameListRows();
            SetupLicenceDisplay();
            StartPingLoop();
            if (!_isGuest) StartExpiryWatcher();
            LoadIspInfo();
            DrawRouteCanvas(null, false);
            if (CboDns != null) CboDns.SelectedIndex = 1;
            LoadStartupState();
            if (!_isGuest) _ = LoadLeaderboard();
            if (_isGuest)  ApplyGuestRestrictions();
            TabConfig.Load();
            RebuildSidebar();
            InitThemePanel();
        }

        // ─── GUEST RESTRICTIONS ───────────────────────────────────────
        private void ApplyGuestRestrictions()
        {
            // Show upgrade banner on every tab
            if (GuestUpgradeBanner != null) GuestUpgradeBanner.Visibility = Visibility.Visible;

            // Lock region selector — ASIA only
            if (_selectedRegion != GuestSession.GuestRegion)
            {
                _selectedRegion = GuestSession.GuestRegion;
                _connectedRegion = null;
            }

            // Disable locked feature buttons
            void Lock(System.Windows.Controls.Control? c) { if (c != null) { c.IsEnabled = false; c.Opacity = 0.3; } }
            Lock(BtnExportLog);
            Lock(BtnScreenshot);
            Lock(BtnGpuBoost);
            Lock(BtnSmartSwitch);
            Lock(BtnDetectThrottle); // actually enabled for guests — show but leave on
            if (BtnDetectThrottle != null) { BtnDetectThrottle.IsEnabled = true; BtnDetectThrottle.Opacity = 1; }

            // Leaderboard — hide submit button and list
            if (LeaderboardList     != null) LeaderboardList.Visibility     = Visibility.Collapsed;
            if (TxtLeaderboardStatus!= null) TxtLeaderboardStatus.Visibility= Visibility.Collapsed;

            // Report card — hide copy button and text
            if (BtnCopyReport != null) BtnCopyReport.Visibility = Visibility.Collapsed;
            if (TxtReportCard != null) TxtReportCard.Visibility = Visibility.Collapsed;

            // Discord RPC — skip
            // (DiscordRPCLoop is not started for guests — no StartDiscordRpc call)

            // Watermark
            if (TxtWatermark != null)
                TxtWatermark.Text = $"GUEST MODE · Session #{_guest?.SessionCount ?? 1} · discord.gg/obsidianlabs";

            SetStatus("Guest mode — ASIA region · 3 games · limited features. Enter a key to unlock all.", "#9A88C4");
        }

        // ─── GUEST UPGRADE (key entered from inside app) ──────────────
        private async void GuestUpgradeKey_Click(object sender, RoutedEventArgs e)
        {
            if (TxtUpgradeKey == null) return;
            string key = TxtUpgradeKey.Text.Trim().ToUpper();
            if (key == "P4NZ-XXXX-XXXX-XXXX" || string.IsNullOrEmpty(key))
            { SetStatus("Enter your key in the upgrade box first.", "#FFD700"); return; }

            if (BtnUpgradeFromGuest != null) BtnUpgradeFromGuest.IsEnabled = false;
            SetStatus("Validating upgrade key...", "#FFD700");

            var result = await KeyValidator.ValidateAsync(key);
            if (result.Status != KeyStatus.Valid)
            {
                SetStatus(result.Message, "#CC3D3D");
                if (BtnUpgradeFromGuest != null) BtnUpgradeFromGuest.IsEnabled = true;
                return;
            }

            // Valid key — migrate guest data and relaunch as licensed
            KeyValidator.SaveKeyFile(key);
            string? migMsg = await GuestSession.MigrateToKeyAsync(key);
            SetStatus(migMsg != null ? $"Key activated! {migMsg}" : "Key activated! Welcome to full access.", "#3DCC5F");
            await Task.Delay(1800);

            // Reopen as full user — smooth restart
            new MainWindow(result, null).Show();
            Close();
        }

        // ─── SIDEBAR NAV ──────────────────────────────────────────────
        private string _currentTab = "home";
        private bool   _compactSidebar = false;

        private void SideNav_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            ShowTab(btn.Tag?.ToString() ?? "home");
        }

        private void ShowTab(string tabId)
        {
            _currentTab = tabId;

            // Hide all panels first
            if (PanelHome     != null) PanelHome.Visibility     = Visibility.Collapsed;
            if (PanelGames    != null) PanelGames.Visibility    = Visibility.Collapsed;
            if (PanelTools    != null) PanelTools.Visibility    = Visibility.Collapsed;
            if (PanelStats    != null) PanelStats.Visibility    = Visibility.Collapsed;
            if (PanelSettings != null) PanelSettings.Visibility = Visibility.Collapsed;
            if (PanelLicence  != null) PanelLicence.Visibility  = Visibility.Collapsed;

            // Show the matched panel from TabConfig
            var tab = TabConfig.Current.FirstOrDefault(t => t.Id == tabId);
            System.Windows.UIElement? activePanel = tab?.PanelName switch
            {
                "PanelHome"     => PanelHome,
                "PanelGames"    => PanelGames,
                "PanelTools"    => PanelTools,
                "PanelStats"    => PanelStats,
                "PanelSettings" => PanelSettings,
                "PanelLicence"  => PanelLicence,
                _               => PanelHome,
            };
            if (activePanel is System.Windows.Controls.StackPanel sp)
                sp.Visibility = Visibility.Visible;

            RegionListPanel.Visibility = tabId == "home"  ? Visibility.Visible : Visibility.Collapsed;
            GameListPanel.Visibility   = tabId == "games" ? Visibility.Visible : Visibility.Collapsed;

            BtnConnect.Visibility    = (tabId == "home" || tabId == "games") ? Visibility.Visible : Visibility.Collapsed;
            BtnDisconnect.Visibility = (tabId == "home" || tabId == "games") ? Visibility.Visible : Visibility.Collapsed;
            BtnAuto.Visibility       = tabId == "home" ? Visibility.Visible : Visibility.Collapsed;
            if (BestTagBorder != null)
                BestTagBorder.Visibility = tabId == "home" ? Visibility.Visible : Visibility.Collapsed;

            // Update breadcrumb using tab label from config
            if (TxtBreadcrumb != null)
                TxtBreadcrumb.Text = tab != null ? $"{tab.Icon}  {tab.Label.ToUpper()}" : "⚡  OPTIMIZE";

            // Update sidebar button styles
            RebuildSidebar();

            // Fade in
            if (activePanel != null)
            {
                activePanel.Opacity = 0;
                var fade = new System.Windows.Media.Animation.DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(180));
                activePanel.BeginAnimation(System.Windows.UIElement.OpacityProperty, fade);
            }

            if (tabId == "settings") InitThemePanel();
        }

        // ─── SIDEBAR REBUILD ─────────────────────────────────────────
        private void RebuildSidebar()
        {
            if (SidebarPanel == null) return;
            SidebarPanel.Children.Clear();

            foreach (var tab in TabConfig.Visible)
            {
                var t = tab; // capture
                bool isActive = t.Id == _currentTab;

                var btn = new System.Windows.Controls.Button
                {
                    Tag    = t.Id,
                    Margin = new Thickness(0, 0, 0, 4),
                    Style  = (Style)FindResource(isActive ? "SideIconBtnActive" : "SideIconBtn"),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    ToolTip = t.Label,
                };

                btn.Content = new System.Windows.Controls.TextBlock
                {
                    Text       = t.Icon,
                    FontSize   = _compactSidebar ? 22 : 20,
                    Foreground = isActive
                        ? new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.Primary))
                        : new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.TextPrimary)),
                };

                btn.Click += (s, e) => ShowTab(t.Id);
                SidebarPanel.Children.Add(btn);
            }
        }

        // ─── TAB CUSTOMIZE PANEL ─────────────────────────────────────
        private void BuildTabCustomizePanel()
        {
            if (TabCustomizePanel == null) return;
            TabCustomizePanel.Children.Clear();

            foreach (var tab in TabConfig.Current)
            {
                var t = tab;
                var row = new Border
                {
                    Background      = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.CardBg)),
                    BorderBrush     = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.CardBg)),
                    BorderThickness = new Thickness(1),
                    CornerRadius    = new CornerRadius(8),
                    Padding         = new Thickness(10, 7, 10, 7),
                    Margin          = new Thickness(0, 0, 0, 4),
                };

                var grid = new System.Windows.Controls.Grid();
                grid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition { Width = new GridLength(32) });
                grid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                grid.ColumnDefinitions.Add(new System.Windows.Controls.ColumnDefinition { Width = GridLength.Auto });

                // Icon button (opens icon picker)
                var iconBtn = new System.Windows.Controls.Button
                {
                    Content  = t.Icon,
                    FontSize = 16,
                    Width    = 28, Height = 28,
                    Cursor   = System.Windows.Input.Cursors.Hand,
                    ToolTip  = "Change icon",
                    Style    = (Style)FindResource("SmallBtn"),
                };
                iconBtn.Click += (s, e) => OpenIconPicker(t.Id, iconBtn);
                System.Windows.Controls.Grid.SetColumn(iconBtn, 0);
                grid.Children.Add(iconBtn);

                // Label (editable inline)
                var nameBox = new System.Windows.Controls.TextBox
                {
                    Text            = t.Label,
                    Foreground      = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.TextPrimary)),
                    Background      = System.Windows.Media.Brushes.Transparent,
                    BorderThickness = new Thickness(0),
                    FontFamily      = new System.Windows.Media.FontFamily("Consolas"),
                    FontSize        = 12,
                    FontWeight      = FontWeights.Bold,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin          = new Thickness(8, 0, 8, 0),
                    IsEnabled       = !t.Locked,
                };
                nameBox.LostFocus += (s, e) => { TabConfig.SetLabel(t.Id, nameBox.Text); RebuildSidebar(); };
                nameBox.KeyDown   += (s, e) => { if (e.Key == System.Windows.Input.Key.Enter) { TabConfig.SetLabel(t.Id, nameBox.Text); RebuildSidebar(); nameBox.MoveFocus(new System.Windows.Input.TraversalRequest(System.Windows.Input.FocusNavigationDirection.Next)); } };
                System.Windows.Controls.Grid.SetColumn(nameBox, 1);
                grid.Children.Add(nameBox);

                // Controls: up / down / eye
                var controls = new System.Windows.Controls.StackPanel
                {
                    Orientation = System.Windows.Controls.Orientation.Horizontal,
                };

                var upBtn = MakeMiniBtn("▲", () => { TabConfig.MoveUp(t.Id);   BuildTabCustomizePanel(); RebuildSidebar(); });
                var dnBtn = MakeMiniBtn("▼", () => { TabConfig.MoveDown(t.Id); BuildTabCustomizePanel(); RebuildSidebar(); });

                var eyeBtn = new System.Windows.Controls.Button
                {
                    Content = t.Visible ? "👁" : "🚫",
                    Width   = 28, Height = 28,
                    Margin  = new Thickness(2, 0, 0, 0),
                    Cursor  = System.Windows.Input.Cursors.Hand,
                    Style   = (Style)FindResource("SmallBtn"),
                    IsEnabled = !t.Locked,
                    Opacity   = t.Locked ? 0.3 : 1,
                    ToolTip   = t.Locked ? "Cannot hide this tab" : (t.Visible ? "Hide tab" : "Show tab"),
                };
                var eyeRef = eyeBtn;
                var tRef   = t;
                eyeBtn.Click += (s, e) =>
                {
                    TabConfig.SetVisible(tRef.Id, !tRef.Visible);
                    eyeRef.Content = tRef.Visible ? "👁" : "🚫";
                    RebuildSidebar();
                };

                controls.Children.Add(upBtn);
                controls.Children.Add(dnBtn);
                controls.Children.Add(eyeBtn);
                System.Windows.Controls.Grid.SetColumn(controls, 2);
                grid.Children.Add(controls);

                row.Child = grid;
                TabCustomizePanel.Children.Add(row);
            }
        }

        private System.Windows.Controls.Button MakeMiniBtn(string label, Action onClick)
        {
            var btn = new System.Windows.Controls.Button
            {
                Content = label, Width = 28, Height = 28,
                Margin  = new Thickness(2, 0, 0, 0),
                Cursor  = System.Windows.Input.Cursors.Hand,
                Style   = (Style)FindResource("SmallBtn"),
            };
            btn.Click += (s, e) => onClick();
            return btn;
        }

        // ─── ICON PICKER POPUP ───────────────────────────────────────
        private void OpenIconPicker(string tabId, System.Windows.Controls.Button sourceBtn)
        {
            var popup = new System.Windows.Controls.Primitives.Popup
            {
                PlacementTarget = sourceBtn,
                Placement       = System.Windows.Controls.Primitives.PlacementMode.Bottom,
                IsOpen          = true,
                StaysOpen       = false,
            };

            var panel = new System.Windows.Controls.WrapPanel
            {
                Width      = 220,
                Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.CardBg)),
            };

            var border = new Border
            {
                Child           = panel,
                Background      = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.CardBg)),
                BorderBrush     = new SolidColorBrush((Color)ColorConverter.ConvertFromString(ThemeManager.Current.Primary)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(6),
            };
            popup.Child = border;

            foreach (var icon in TabIcons.All)
            {
                var ic = icon;
                var b = new System.Windows.Controls.Button
                {
                    Content  = ic,
                    FontSize = 18,
                    Width    = 34, Height = 34,
                    Margin   = new Thickness(2),
                    Cursor   = System.Windows.Input.Cursors.Hand,
                    Style    = (Style)FindResource("SmallBtn"),
                };
                b.Click += (s, e) =>
                {
                    TabConfig.SetIcon(tabId, ic);
                    sourceBtn.Content = ic;
                    popup.IsOpen = false;
                    BuildTabCustomizePanel();
                    RebuildSidebar();
                };
                panel.Children.Add(b);
            }
            popup.IsOpen = true;
        }

        // ─── COMPACT SIDEBAR TOGGLE ──────────────────────────────────
        private void CompactSidebar_Click(object sender, RoutedEventArgs e)
        {
            _compactSidebar = !_compactSidebar;
            if (BtnCompactSidebar != null)
                BtnCompactSidebar.Content = _compactSidebar ? "DISABLE" : "ENABLE";
            RebuildSidebar();
            SetStatus(_compactSidebar ? "Compact sidebar enabled." : "Compact sidebar disabled.", "#9A88C4");
        }

        private void ResetTabs_Click(object sender, RoutedEventArgs e)
        {
            TabConfig.ResetToDefaults();
            BuildTabCustomizePanel();
            RebuildSidebar();
            SetStatus("Tabs reset to defaults.", "#9A88C4");
        }

        // ─── SEARCH ───────────────────────────────────────────────────
        private void TxtSearch_Changed(object sender, TextChangedEventArgs e)
        {
            if (TxtSearch == null || SearchHint == null) return;
            SearchHint.Visibility = string.IsNullOrEmpty(TxtSearch.Text)
                ? Visibility.Visible : Visibility.Collapsed;

            string q = TxtSearch.Text.Trim().ToLower();
            if (GameListStack == null) return;
            foreach (Button btn in GameListStack.Children.OfType<Button>())
            {
                string name = btn.Tag?.ToString()?.ToLower() ?? "";
                btn.Visibility = string.IsNullOrEmpty(q) || name.Contains(q)
                    ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        // ─── BUILD UI ─────────────────────────────────────────────────
        private void BuildRegionButtons()
        {
            foreach (var r in Regions)
            {
                var btn = r.Id switch
                {
                    "US"   => BtnUS,
                    "EU"   => BtnEU,
                    "ASIA" => BtnASIA,
                    "BR"   => BtnBR,
                    "AU"   => BtnAU,
                    _      => null
                };
                if (btn == null) continue;

                var pingLbl = new TextBlock
                {
                    Text       = "---ms",
                    Foreground = Clr("#7A6A9E"),
                    FontFamily = new FontFamily("Consolas"),
                    FontSize   = 12,
                    FontWeight = FontWeights.Bold
                };
                btn.Content = new Grid
                {
                    Children =
                    {
                        new StackPanel
                        {
                            VerticalAlignment = VerticalAlignment.Center,
                            Children =
                            {
                                new StackPanel
                                {
                                    Orientation = Orientation.Horizontal,
                                    Children    =
                                    {
                                        new TextBlock { Text = r.Flag, FontSize = 16, Margin = new Thickness(0,0,10,0), VerticalAlignment = VerticalAlignment.Center },
                                        new StackPanel
                                        {
                                            VerticalAlignment = VerticalAlignment.Center,
                                            Children =
                                            {
                                                new TextBlock { Text = r.Name, Foreground = Clr("#C4B8E8"), FontFamily = new FontFamily("Consolas"), FontSize = 12, FontWeight = FontWeights.Bold },
                                                new TextBlock { Text = r.Sub,  Foreground = Clr("#9A88C4"), FontFamily = new FontFamily("Consolas"), FontSize = 11 }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        new StackPanel
                        {
                            HorizontalAlignment = HorizontalAlignment.Right,
                            VerticalAlignment   = VerticalAlignment.Center,
                            Children            = { pingLbl }
                        }
                    }
                };
                _pingLabels[r.Id] = pingLbl;
                _regionBtns[r.Id] = btn;
                _regionPings[r.Id] = -1;
            }
        }

        private void BuildGameListRows()
        {
            if (GameListStack == null) return;
            GameListStack.Children.Clear();
            var gameList = _isGuest
                ? Games.Where(g => GuestSession.GuestGames.Contains(g.Name)).ToList()
                : Games.ToList();
            foreach (var g in gameList)
            {
                var btn = new Button
                {
                    Style  = (Style)FindResource("GameRowBtn"),
                    Tag    = g.Name,
                    Content = new StackPanel
                    {
                        Orientation = Orientation.Horizontal,
                        Children    =
                        {
                            new TextBlock { Text = g.Emoji, FontSize = 18, Margin = new Thickness(0,0,10,0), VerticalAlignment = VerticalAlignment.Center },
                            new StackPanel
                            {
                                VerticalAlignment = VerticalAlignment.Center,
                                Children =
                                {
                                    new TextBlock { Text = g.Name, Foreground = Clr("#C4B8E8"), FontFamily = new FontFamily("Consolas"), FontSize = 12, FontWeight = FontWeights.Bold },
                                    new TextBlock { Text = $"Best: {GetName(g.BestRegion)}", Foreground = Clr("#9A88C4"), FontFamily = new FontFamily("Consolas"), FontSize = 11 }
                                }
                            }
                        }
                    }
                };
                var game = g;
                btn.Click += (s, e) => SelectGame(game, btn);
                GameListStack.Children.Add(btn);
            }
        }

        private void SelectGame(GameProfile game, Button clickedBtn)
        {
            if (GameListStack == null) return;
            _selectedGame = game;
            foreach (Button b in GameListStack.Children.OfType<Button>())
                b.Style = (Style)FindResource("GameRowBtn");
            clickedBtn.Style = (Style)FindResource("GameRowBtnActive");

            if (TxtGameEmoji != null)    TxtGameEmoji.Text       = game.Emoji;
            if (TxtGameName != null)     TxtGameName.Text        = game.Name;
            if (TxtGameRegionLine != null) TxtGameRegionLine.Text = $"Best region: {GetName(game.BestRegion)}";
            if (TxtGameRegionVal != null) TxtGameRegionVal.Text  = GetName(game.BestRegion);
            if (TxtGameTip != null)      TxtGameTip.Text         = game.Tip;

            if (GameDetailCard != null) GameDetailCard.Visibility = Visibility.Visible;
            if (NoGameCard != null)     NoGameCard.Visibility     = Visibility.Collapsed;

            Dispatcher.InvokeAsync(() => DrawGameRouteCanvas(game), DispatcherPriority.Loaded);
        }

        // ─── PING LOOP ────────────────────────────────────────────────
        private void StartPingLoop()
        {
            _pingTimer.Interval = TimeSpan.FromSeconds(2);
            _pingTimer.Tick    += async (s, e) => await PingAllRegionsAsync();
            _pingTimer.Start();
        }

        private async Task PingAllRegionsAsync()
        {
            foreach (var r in Regions)
            {
                int ms = await DoPingAsync(r.PingIp);
                _regionPings[r.Id] = ms;

                if (_pingLabels.TryGetValue(r.Id, out var lbl))
                {
                    lbl.Text       = ms > 0 ? $"{ms}ms" : "---";
                    lbl.Foreground = PingBrush(ms);
                }

                if (r.Id == _connectedRegion && ms > 0)
                {
                    UpdateConnectedPing(ms);
                }
            }

            UpdateBestRegionTag();

            // Auto-reconnect check
            if (_connectedRegion != null && _autoReconnectEnabled)
            {
                int currentMs = _regionPings.TryGetValue(_connectedRegion, out int v) ? v : -1;
                if (currentMs < 0)
                {
                    _consecutiveFails++;
                    if (_consecutiveFails >= MaxConsecutiveFails)
                    {
                        _consecutiveFails = 0;
                        SetStatus("Connection lost — auto-reconnecting...", "#FFD700");
                        await Task.Delay(1000);
                        await DoConnectAsync(_connectedRegion);
                    }
                }
                else
                {
                    _consecutiveFails = 0;
                }
            }
        }

        private async void UpdateConnectedPing(int ms)
        {
            // Jitter
            if (_history.Count > 0)
            {
                int j = Math.Abs(ms - _history.Last());
                _jitterSamples.Add(j);
                if (_jitterSamples.Count > MaxJitter) _jitterSamples.RemoveAt(0);
                int avgJitter = _jitterSamples.Any() ? (int)_jitterSamples.Average() : 0;
                if (TxtJitter != null)
                {
                    TxtJitter.Text       = avgJitter.ToString();
                    TxtJitter.Foreground = PingBrush(avgJitter * 3);
                }
            }
            // Loss
            bool lost = ms < 0;
            _lossWindow.Enqueue(lost);
            if (_lossWindow.Count > LossWindow) _lossWindow.Dequeue();
            int lossCount = _lossWindow.Count(x => x);
            double lossPct = _lossWindow.Count > 0 ? lossCount * 100.0 / _lossWindow.Count : 0;
            if (TxtPacketLoss != null)
            {
                TxtPacketLoss.Text       = $"{(int)lossPct}";
                TxtPacketLoss.Foreground = lossPct < 1 ? Clr("#3DCC5F") : lossPct < 5 ? Clr("#FFD700") : Clr("#CC3D3D");
            }

            // History
            if (ms > 0)
            {
                _history.Add(ms);
                if (_history.Count > MaxHist) _history.RemoveAt(0);
                DrawGraph();
            }

            // Big ping
            if (ms > 0)
            {
                if (TxtBigPing != null) { TxtBigPing.Text = ms.ToString(); TxtBigPing.Foreground = PingBrush(ms); }
                UpdateSignalBar(ms);
                if (TxtPing != null)    { TxtPing.Text    = ms.ToString(); TxtPing.Foreground    = PingBrush(ms); }
                if (TxtAfter != null)   TxtAfter.Text     = ms.ToString();

                // Latency tier
                UpdateLatencyTier(ms);

                // Session stats
                if (ms < _sessionBest)  _sessionBest  = ms;
                if (ms > _sessionWorst) _sessionWorst = ms;
                if (TxtBestPing != null)  TxtBestPing.Text  = _sessionBest  == int.MaxValue ? "---" : _sessionBest.ToString();
                if (TxtWorstPing != null) TxtWorstPing.Text = _sessionWorst == 0            ? "---" : _sessionWorst.ToString();

                if (_history.Count > 0)
                {
                    int avg = (int)_history.Average();
                    if (TxtAvgPing != null)       TxtAvgPing.Text       = avg.ToString();
                    if (TxtAvgPingSmall != null)  TxtAvgPingSmall.Text  = avg.ToString();
                }

                if (_beforePing > 0)
                {
                    int saved = _beforePing - ms;
                    if (TxtSavedMs != null)    TxtSavedMs.Text    = saved.ToString();
                    if (TxtSavedLabel != null) TxtSavedLabel.Text = saved > 0 ? $"You saved {saved}ms this session 🎉" : "Keep connected for improvement data";
                    UpdatePingCompare();
                    UpdateReportCard();
                    CheckPingGuarantee(ms);
                    await CheckSmartSwitch(ms);
                    // Update guest stats in Firebase every 10 pings
                    if (_isGuest && _history.Count % 10 == 0)
                        GuestSession.UpdateStats(_selectedGame?.Name, _connectedRegion, ms > 0 ? ms : 999);
                }

                // Ping log
                if (PingLog != null)
                {
                    string entry = $"[{DateTime.Now:HH:mm:ss}]  {_connectedRegion,-5}  {ms,4}ms  Jitter:{(_jitterSamples.Any() ? (int)_jitterSamples.Average() : 0)}ms  Loss:{(int)lossPct}%";
                    PingLog.Items.Add(entry);
                    if (PingLog.Items.Count > 500) PingLog.Items.RemoveAt(0);
                    PingLog.ScrollIntoView(PingLog.Items[^1]);
                }

                // Connection score
                UpdateConnectionScore(ms, _jitterSamples.Any() ? (int)_jitterSamples.Average() : 0, lossPct);

                // Spike alert
                if (_spikeAlertEnabled && ms > _spikeThreshold)
                    ShowSpikeAlert(ms);
            }

            if (TxtPingStatus != null)
            {
                TxtPingStatus.Text       = ms > 0 ? $"{_connectedRegion}  {ms}ms" : "● TIMEOUT";
                TxtPingStatus.Foreground = ms > 0 ? PingBrush(ms) : Clr("#CC3D3D");
            }
        }

        private void UpdateLatencyTier(int ms)
        {
            if (TxtLatencyTier == null || LatencyBadge == null) return;
            if (ms < 50)
            {
                TxtLatencyTier.Text       = "EXCELLENT";
                TxtLatencyTier.Foreground = Clr("#3DCC5F");
                LatencyBadge.BorderBrush  = Clr("#3DCC5F");
                LatencyBadge.Background   = Clr("#081A08");
            }
            else if (ms < 100)
            {
                TxtLatencyTier.Text       = "GOOD";
                TxtLatencyTier.Foreground = Clr("#9DFF50");
                LatencyBadge.BorderBrush  = Clr("#9DFF50");
                LatencyBadge.Background   = Clr("#0A1A04");
            }
            else if (ms < 150)
            {
                TxtLatencyTier.Text       = "FAIR";
                TxtLatencyTier.Foreground = Clr("#FFD700");
                LatencyBadge.BorderBrush  = Clr("#FFD700");
                LatencyBadge.Background   = Clr("#1A1400");
            }
            else if (ms < 250)
            {
                TxtLatencyTier.Text       = "POOR";
                TxtLatencyTier.Foreground = Clr("#FF8800");
                LatencyBadge.BorderBrush  = Clr("#FF8800");
                LatencyBadge.Background   = Clr("#1A0A00");
            }
            else
            {
                TxtLatencyTier.Text       = "CRITICAL";
                TxtLatencyTier.Foreground = Clr("#CC3D3D");
                LatencyBadge.BorderBrush  = Clr("#CC3D3D");
                LatencyBadge.Background   = Clr("#1A0808");
            }
        }

        private void UpdateConnectionScore(int ms, int jitter, double lossPct)
        {
            if (ScoreBar == null || TxtScoreGrade == null || TxtScoreLabel == null) return;
            int pingScore   = ms < 50 ? 40 : ms < 100 ? 32 : ms < 150 ? 20 : ms < 250 ? 10 : 0;
            int jitterScore = jitter < 10 ? 35 : jitter < 30 ? 25 : jitter < 60 ? 14 : 4;
            int lossScore   = lossPct < 0.5 ? 25 : lossPct < 2 ? 18 : lossPct < 5 ? 8 : 0;
            int total       = pingScore + jitterScore + lossScore;

            string grade = total >= 90 ? "A+" : total >= 80 ? "A" : total >= 70 ? "B" : total >= 55 ? "C" : total >= 35 ? "D" : "F";
            TxtScoreGrade.Text       = grade;
            TxtScoreGrade.Foreground = total >= 70 ? Clr("#3DCC5F") : total >= 45 ? Clr("#FFD700") : Clr("#CC3D3D");
            TxtScoreLabel.Text       = $"Score: {total}/100  ({grade})";

            double maxW = ScoreBar.Tag is double d ? d : 0;
            if (maxW <= 0 && ScoreBar.Parent is Border pb)
            {
                maxW = pb.ActualWidth > 20 ? pb.ActualWidth - 20 : 160;
                ScoreBar.Tag = maxW;
            }
            ScoreBar.Width = maxW * (total / 100.0);
        }

        private void UpdateBestRegionTag()
        {
            if (TxtBestTag == null) return;
            var best = _regionPings.Where(kvp => kvp.Value > 0).OrderBy(kvp => kvp.Value).FirstOrDefault();
            TxtBestTag.Text = best.Key != null ? $"Best: {GetName(best.Key)} — {best.Value}ms" : "Scanning regions...";
        }

        // ─── SPIKE ALERT ─────────────────────────────────────────────
        private DateTime _lastSpikeAlert = DateTime.MinValue;
        private void ShowSpikeAlert(int ms)
        {
            if ((DateTime.Now - _lastSpikeAlert).TotalSeconds < 10) return;
            _lastSpikeAlert = DateTime.Now;
            if (SpikeAlertBadge == null || TxtSpikeAlert == null) return;
            TxtSpikeAlert.Text       = $"⚠ SPIKE: {ms}ms (>{_spikeThreshold})";
            SpikeAlertBadge.Visibility = Visibility.Visible;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(5) };
            timer.Tick += (s, e) => { if (SpikeAlertBadge != null) SpikeAlertBadge.Visibility = Visibility.Collapsed; timer.Stop(); };
            timer.Start();
        }

        // ─── SETTINGS HANDLERS ────────────────────────────────────────
        private void SpikeToggle_Click(object sender, RoutedEventArgs e)
        {
            if (TxtSpikeThreshold != null && int.TryParse(TxtSpikeThreshold.Text.Trim(), out int thresh) && thresh > 0)
                _spikeThreshold = thresh;

            _spikeAlertEnabled = !_spikeAlertEnabled;
            if (BtnSpikeToggle != null) BtnSpikeToggle.Content = _spikeAlertEnabled ? "DISABLE" : "ENABLE";
            if (TxtSpikeStatus != null)
            {
                TxtSpikeStatus.Text       = _spikeAlertEnabled ? $"ENABLED (>{_spikeThreshold}ms)" : "DISABLED";
                TxtSpikeStatus.Foreground = _spikeAlertEnabled ? Clr("#3DCC5F") : Clr("#7A6A9E");
            }
            SetStatus(_spikeAlertEnabled ? $"Spike alert enabled — will warn above {_spikeThreshold}ms" : "Spike alert disabled.", "#9A88C4");
        }

        private void AutoReconnect_Click(object sender, RoutedEventArgs e)
        {
            _autoReconnectEnabled = !_autoReconnectEnabled;
            if (BtnAutoReconnect != null) BtnAutoReconnect.Content = _autoReconnectEnabled ? "DISABLE" : "ENABLE";
            if (TxtAutoReconnectStatus != null)
            {
                TxtAutoReconnectStatus.Text       = _autoReconnectEnabled ? "ENABLED" : "DISABLED";
                TxtAutoReconnectStatus.Foreground = _autoReconnectEnabled ? Clr("#3DCC5F") : Clr("#7A6A9E");
            }
            SetStatus(_autoReconnectEnabled ? "Auto-reconnect ON — will reconnect if connection drops." : "Auto-reconnect disabled.", "#9A88C4");
        }

        private void Startup_Click(object sender, RoutedEventArgs e)
        {
            _startupEnabled = !_startupEnabled;
            SetWindowsStartup(_startupEnabled);
            if (BtnStartup != null) BtnStartup.Content = _startupEnabled ? "DISABLE" : "ENABLE";
            if (TxtStartupStatus != null)
            {
                TxtStartupStatus.Text       = _startupEnabled ? "ENABLED — starts with Windows" : "DISABLED";
                TxtStartupStatus.Foreground = _startupEnabled ? Clr("#3DCC5F") : Clr("#7A6A9E");
            }
        }

        private void StreamerMode_Click(object sender, RoutedEventArgs e)
        {
            _streamerMode = !_streamerMode;
            ApplyStreamerMode(_streamerMode);
            if (BtnStreamer != null)     BtnStreamer.Content = _streamerMode ? "DISABLE" : "ENABLE";
            if (TxtStreamerStatus != null)
            {
                TxtStreamerStatus.Text       = _streamerMode ? "ENABLED — sensitive info hidden" : "DISABLED";
                TxtStreamerStatus.Foreground = _streamerMode ? Clr("#FFD700") : Clr("#7A6A9E");
            }
            SetStatus(_streamerMode ? "Streamer mode ON — IP, ISP and key info hidden." : "Streamer mode OFF — all info visible.", _streamerMode ? "#FFD700" : "#9A88C4");
        }

        private void ApplyStreamerMode(bool hide)
        {
            string mask = "██████████";
            if (TxtMyIP     != null) TxtMyIP.Text     = hide ? "●●●.●●●.●●●.●●●" : _cachedIp;
            if (TxtISP      != null) TxtISP.Text      = hide ? mask : _cachedIsp;
            if (TxtLocation != null) TxtLocation.Text = hide ? "Hidden" : _cachedLocation;
            if (!_isGuest && _licence != null)
            {
                if (TxtBuyerName != null) TxtBuyerName.Text = hide ? "Licensed to: ██████████" : $"Licensed to: {_licence.Buyer}  ·  {_licence.Plan}";
                if (TxtWatermark != null) TxtWatermark.Text = hide ? "p4inz Ping Reducer v5.6 — streamer mode" : $"p4inz Ping Reducer v5.6 — discord.gg/obsidianlabs — {_licence.Buyer}";
                if (!hide) UpdateDaysLeft();
            }
            if (TxtPingStatus != null && _connectedRegion != null)
                TxtPingStatus.Text = hide ? "CONNECTED" : $"{_connectedRegion}  {(_history.LastOrDefault())}ms";
        }

        // Cached ISP values for streamer toggle restore
        private string _cachedIp = "---", _cachedIsp = "---", _cachedLocation = "---";

        private void NeonEdge_Click(object sender, RoutedEventArgs e)
        {
            _neonEdgeOn = !_neonEdgeOn;
            if (MainBorder != null)
            {
                if (_neonEdgeOn)
                {
                    MainBorder.BorderThickness = new Thickness(2);
                    MainBorder.BorderBrush = new LinearGradientBrush(
                        new GradientStopCollection
                        {
                            new GradientStop((Color)ColorConverter.ConvertFromString("#B43CFF"), 0.0),
                            new GradientStop((Color)ColorConverter.ConvertFromString("#FF2060"), 0.33),
                            new GradientStop((Color)ColorConverter.ConvertFromString("#4040FF"), 0.66),
                            new GradientStop((Color)ColorConverter.ConvertFromString("#B43CFF"), 1.0),
                        },
                        new System.Windows.Point(0, 0),
                        new System.Windows.Point(1, 1));
                }
                else
                {
                    MainBorder.BorderThickness = new Thickness(1);
                    MainBorder.BorderBrush = Clr("#2A1050");
                }
            }
            if (BtnNeon != null)     BtnNeon.Content = _neonEdgeOn ? "DISABLE" : "ENABLE";
            if (TxtNeonStatus != null)
            {
                TxtNeonStatus.Text       = _neonEdgeOn ? "ENABLED — neon glow active" : "DISABLED";
                TxtNeonStatus.Foreground = _neonEdgeOn ? Clr("#B43CFF") : Clr("#7A6A9E");
            }
        }

        private async void ApplyMtu_Click(object sender, RoutedEventArgs e)
        {
            if (TxtMtu == null || !int.TryParse(TxtMtu.Text.Trim(), out int mtu) || mtu < 576 || mtu > 9000)
            {
                SetStatus("Invalid MTU value. Use 576–9000 (1480 recommended for gaming).", "#CC3D3D");
                return;
            }
            if (TxtMtuStatus != null) TxtMtuStatus.Text = $"Applying MTU {mtu}...";
            try
            {
                var adapters = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                                (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                                 n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                                !n.Description.Contains("Virtual") && !n.Description.Contains("Hyper-V") &&
                                !n.Description.Contains("VMware") && !n.Description.Contains("Loopback"));
                foreach (var a in adapters)
                    await RunCmdAsync("netsh", $"interface ipv4 set subinterface \"{a.Name}\" mtu={mtu} store=persistent");
                if (TxtMtuStatus != null) TxtMtuStatus.Text = $"MTU set to {mtu} on all active adapters.";
                SetStatus($"MTU optimized to {mtu}.", "#3DCC5F");
            }
            catch { if (TxtMtuStatus != null) TxtMtuStatus.Text = "Failed — run as Administrator."; }
        }

        private async void PingTarget_Click(object sender, RoutedEventArgs e)
        {
            if (TxtCustomTarget == null || TxtCustomPingResult == null) return;
            string target = TxtCustomTarget.Text.Trim();
            if (string.IsNullOrEmpty(target) || target.StartsWith("e.g.")) return;
            TxtCustomPingResult.Text = "Pinging...";
            try
            {
                // Resolve hostname if needed
                string ip = target;
                if (!System.Net.IPAddress.TryParse(target, out _))
                {
                    var addrs = await Dns.GetHostAddressesAsync(target);
                    ip = addrs.FirstOrDefault()?.ToString() ?? target;
                }
                int ms = await DoPingAsync(ip);
                TxtCustomPingResult.Text       = ms > 0 ? $"{ms}ms  ({ip})" : "Timeout — host unreachable";
                TxtCustomPingResult.Foreground = ms > 0 ? PingBrush(ms) : Clr("#CC3D3D");
            }
            catch (Exception ex)
            {
                TxtCustomPingResult.Text       = $"Error: {ex.Message}";
                TxtCustomPingResult.Foreground = Clr("#CC3D3D");
            }
        }

        // ─── EXPORT LOG ───────────────────────────────────────────────
        private void ExportLog_Click(object sender, RoutedEventArgs e)
        {
            if (PingLog == null || PingLog.Items.Count == 0)
            {
                SetStatus("No log data to export — connect and run a session first.", "#CC3D3D");
                return;
            }
            var dlg = new SaveFileDialog
            {
                FileName   = $"p4inz_pingreducer_session_{DateTime.Now:yyyyMMdd_HHmm}.txt",
                DefaultExt = ".txt",
                Filter     = "Text files (*.txt)|*.txt"
            };
            if (dlg.ShowDialog() != true) return;
            var lines = PingLog.Items.Cast<string>().ToList();
            lines.Insert(0, $"p4inz Ping Reducer v5.6 — Session Log — {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            string buyerLine = _licence != null ? $"Region: {_connectedRegion ?? "N/A"}  |  Buyer: {_licence.Buyer}  |  Plan: {_licence.Plan}" : $"Region: {_connectedRegion ?? "N/A"}  |  Guest Mode";
            lines.Insert(1, buyerLine);
            lines.Insert(2, new string('─', 60));
            File.WriteAllLines(dlg.FileName, lines);
            SetStatus($"Log exported to {System.IO.Path.GetFileName(dlg.FileName)}", "#3DCC5F");
        }

        // ─── STARTUP REGISTRY ─────────────────────────────────────────
        private void LoadStartupState()
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false);
                _startupEnabled = key?.GetValue("p4inzPingReducer") != null;
                if (BtnStartup != null)     BtnStartup.Content = _startupEnabled ? "DISABLE" : "ENABLE";
                if (TxtStartupStatus != null)
                {
                    TxtStartupStatus.Text       = _startupEnabled ? "ENABLED — starts with Windows" : "DISABLED";
                    TxtStartupStatus.Foreground = _startupEnabled ? Clr("#3DCC5F") : Clr("#7A6A9E");
                }
            }
            catch { }
        }

        private static void SetWindowsStartup(bool enable)
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                if (enable)
                    key?.SetValue("p4inzPingReducer", $"\"{Process.GetCurrentProcess().MainModule?.FileName ?? ""}\"");
                else
                    key?.DeleteValue("p4inzPingReducer", false);
            }
            catch { }
        }

        // ─── CONNECT / DISCONNECT ─────────────────────────────────────
        private void Region_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn) return;
            string id = btn.Tag?.ToString() ?? "";
            _selectedRegion = id;

            foreach (var kvp in _regionBtns)
                kvp.Value.Style = (Style)FindResource(kvp.Key == id ? "RegionRowBtnActive" : "RegionRowBtn");

            if (BtnConnect != null) BtnConnect.IsEnabled = true;
        }

        private async void Connect_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedRegion == null) return;
            var dialog = new OptimizationDialog { Owner = this };
            if (dialog.ShowDialog() != true) return;
            _optMode = dialog.ChosenMode;
            await DoConnectAsync(_selectedRegion);
        }

        private async void AutoConnect_Click(object sender, RoutedEventArgs e)
        {
            var best = _regionPings.Where(kvp => kvp.Value > 0).OrderBy(kvp => kvp.Value).FirstOrDefault();
            if (best.Key == null) { SetStatus("Still scanning regions — try again in a moment.", "#FFD700"); return; }

            _selectedRegion = best.Key;
            foreach (var kvp in _regionBtns)
                kvp.Value.Style = (Style)FindResource(kvp.Key == _selectedRegion ? "RegionRowBtnActive" : "RegionRowBtn");

            var dialog = new OptimizationDialog { Owner = this };
            if (dialog.ShowDialog() != true) return;
            _optMode = dialog.ChosenMode;
            await DoConnectAsync(_selectedRegion);
        }

        private async void OneClick_Click(object sender, RoutedEventArgs e)
        {
            var best = _regionPings.Where(kvp => kvp.Value > 0).OrderBy(kvp => kvp.Value).FirstOrDefault();
            if (best.Key == null) { SetStatus("Still scanning — wait a moment then try One-Click.", "#FFD700"); return; }
            _selectedRegion = best.Key;
            _optMode = OptMode.Safe;
            await DoConnectAsync(_selectedRegion);
        }

        private async void ApplyProfile_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedGame == null) return;
            _selectedRegion = _selectedGame.BestRegion;
            _activeDns      = _selectedGame.Dns;
            _optMode        = OptMode.Safe;
            await DoConnectAsync(_selectedRegion);
        }

        private async Task DoConnectAsync(string regionId)
        {
            // Guest mode — ASIA only
            if (_isGuest && regionId != GuestSession.GuestRegion)
            {
                SetStatus("ASIA region only in Guest mode. Get a key to unlock all regions.", "#9A88C4");
                if (GuestUpgradeBanner != null) GuestUpgradeBanner.BringIntoView();
                return;
            }
            if (BtnConnect    != null) BtnConnect.IsEnabled    = false;
            if (BtnDisconnect != null) BtnDisconnect.IsEnabled = false;
            if (BtnAuto       != null) BtnAuto.IsEnabled       = false;
            if (LoadingBar    != null) LoadingBar.Visibility   = Visibility.Visible;

            SetStatus($"Connecting to {GetName(regionId)}...", "#B43CFF");

            // Capture before ping
            if (_regionPings.TryGetValue(regionId, out int before) && before > 0)
            {
                _beforePing = before;
                if (TxtBefore != null) TxtBefore.Text = before.ToString();
            }

            await AnimateLoadingBarAsync();

            // Find best physical adapter
            string bestAdapter = "";
            try
            {
                bestAdapter = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                                (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                                 n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                                !n.Description.Contains("Virtual") && !n.Description.Contains("Hyper-V") &&
                                !n.Description.Contains("VMware") && !n.Description.Contains("Loopback") &&
                                !n.Description.Contains("Bluetooth"))
                    .FirstOrDefault()?.Name ?? "";
            }
            catch { }

            // Apply optimizations
            await ApplyDnsToAdapterAsync(_activeDns, bestAdapter);
            await FlushDnsAsync();

            if (_optMode == OptMode.Medium || _optMode == OptMode.Beast)
            {
                await RunCmdAsync("netsh", "int tcp set global autotuninglevel=highlyrestricted");
                await RunCmdAsync("netsh", "interface tcp set heuristics disabled");
                SetRegistryOpt(true);
            }
            if (_optMode == OptMode.Beast)
            {
                await RunCmdAsync("netsh", "int tcp set global rss=enabled");
                await RunCmdAsync("netsh", "int tcp set global timestamps=disabled");
            }

            _connectedRegion = regionId;
            _sessionStart    = DateTime.Now;
            _sessionBest     = int.MaxValue;
            _sessionWorst    = 0;
            _consecutiveFails = 0;

            if (LoadingBar != null) LoadingBar.Visibility = Visibility.Collapsed;
            if (BtnConnect    != null) { BtnConnect.IsEnabled    = false; }
            if (BtnDisconnect != null) { BtnDisconnect.IsEnabled = true; }
            if (BtnAuto       != null) { BtnAuto.IsEnabled       = false; }

            StartSessionTimer();
            DrawRouteCanvas(regionId, true);
            SetStatus($"Connected to {GetName(regionId)} — optimization: {_optMode}", "#3DCC5F");

            if (TxtPingStatus != null)
            {
                TxtPingStatus.Text = $"CONNECTED — {GetName(regionId)}";
                TxtPingStatus.Foreground = Clr("#3DCC5F");
            }
            if (TxtLatencyTier != null) TxtLatencyTier.Text = "CONNECTED";

            // Start pulse animation on connected dot
            StartConnectionPulse(true);
        }

        private async void Disconnect_Click(object sender, RoutedEventArgs e)
        {
            if (BtnDisconnect != null) BtnDisconnect.IsEnabled = false;

            await RestoreDnsAsync();
            if (_optMode == OptMode.Medium || _optMode == OptMode.Beast)
            {
                await RunCmdAsync("netsh", "int tcp set global autotuninglevel=normal");
                await RunCmdAsync("netsh", "interface tcp set heuristics enabled");
                SetRegistryOpt(false);
            }
            if (_optMode == OptMode.Beast)
            {
                await RunCmdAsync("netsh", "int tcp set global timestamps=enabled");
            }

            _connectedRegion  = null;
            _optMode          = OptMode.None;
            _consecutiveFails = 0;

            _sessionTimer.Stop();
            DrawRouteCanvas(null, false);
            SetStatus("Disconnected — all changes restored.", "#9A88C4");
            StartConnectionPulse(false);
            UpdateSignalBar(0);

            if (TxtPingStatus != null) { TxtPingStatus.Text = "NOT CONNECTED"; TxtPingStatus.Foreground = Clr("#5A4878"); }
            if (TxtBigPing    != null) { TxtBigPing.Text    = "---"; TxtBigPing.Foreground = Clr("#7A6A9E"); }
            if (TxtLatencyTier != null) { TxtLatencyTier.Text = "NOT CONNECTED"; TxtLatencyTier.Foreground = Clr("#7A6A9E"); }
            if (TxtScoreGrade != null)  TxtScoreGrade.Text = "--";
            if (BtnConnect    != null) BtnConnect.IsEnabled = _selectedRegion != null;
            if (BtnAuto       != null) BtnAuto.IsEnabled    = true;
            _history.Clear(); _jitterSamples.Clear(); _lossWindow.Clear();
            if (PingGraph != null) PingGraph.Children.Clear();
        }

        // ─── SESSION TIMER ────────────────────────────────────────────
        private void StartSessionTimer()
        {
            _sessionTimer.Stop();
            _sessionTimer.Interval = TimeSpan.FromSeconds(1);
            _sessionTimer.Tick += (s, e) =>
            {
                var elapsed = DateTime.Now - _sessionStart;
                if (TxtSessionTime != null) TxtSessionTime.Text = elapsed.ToString(@"mm\:ss");
            };
            _sessionTimer.Start();
        }

        // ─── FPS BOOST ────────────────────────────────────────────────
        private async void FpsBoost_Click(object sender, RoutedEventArgs e)
        {
            _fpsBoostOn = !_fpsBoostOn;
            if (_fpsBoostOn) await EnableFpsBoost();
            else             DisableFpsBoost();
            if (BtnFpsBoost != null)
            {
                BtnFpsBoost.Content    = _fpsBoostOn ? "ON" : "OFF";
                BtnFpsBoost.Foreground  = Clr(_fpsBoostOn ? "#3DCC5F" : "#7A6A9E");
                BtnFpsBoost.Background = _fpsBoostOn ? Clr("#0A2A0A") : Clr("#0A1A0A");
                BtnFpsBoost.BorderBrush = _fpsBoostOn ? Clr("#2A6A2A") : Clr("#0A2A12");
            }
        }
        private async Task EnableFpsBoost()
        {
            await RunCmdAsync("powercfg", "/setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c");
            SetRegistryValue(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games", "GPU Priority", 8);
            SetRegistryValue(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games", "Priority", 6);
            await RunCmdAsync("reg", @"add ""HKCU\System\GameConfigStore"" /v GameDVR_Enabled /t REG_DWORD /d 0 /f");
            SetStatus("FPS Boost ON — High Performance mode active.", "#3DCC5F");
        }
        private void DisableFpsBoost()
        {
            try { _ = RunCmdAsync("powercfg", "/setactive 381b4222-f694-41f0-9685-ff5bb260df2e"); } catch { }
            SetStatus("FPS Boost OFF — power plan restored.", "#9A88C4");
        }

        // ─── LICENCE ─────────────────────────────────────────────────
        private void SetupLicenceDisplay()
        {
            if (_isGuest)
            {
                if (TxtBuyerName != null) TxtBuyerName.Text = $"Guest Mode  ·  Session #{_guest?.SessionCount ?? 1}  ·  Limited features";
                if (TxtDaysLeft  != null) { TxtDaysLeft.Text = "GUEST"; TxtDaysLeft.Foreground = Clr("#9A88C4"); }
                if (TxtWatermark != null) TxtWatermark.Text  = $"GUEST MODE · p4inz Ping Reducer v5.6 · discord.gg/obsidianlabs";
                if (LicenceCard  != null) { LicenceCard.BorderBrush = Clr("#2A1E44"); LicenceCard.Background = Clr("#0A0818"); }
                if (TxtLicenceLine1 != null) { TxtLicenceLine1.Text = "GUEST MODE"; TxtLicenceLine1.Foreground = Clr("#9A88C4"); }
                if (BtnRenew != null) BtnRenew.Visibility = Visibility.Collapsed;
                return;
            }
            if (_licence == null) return;
            if (TxtBuyerName != null)  TxtBuyerName.Text = $"Licensed to: {_licence.Buyer}  ·  {_licence.Plan}";
            if (TxtWatermark != null)  TxtWatermark.Text  = $"p4inz Ping Reducer v5.6 — discord.gg/obsidianlabs — {_licence.Buyer}";
            UpdateDaysLeft();
        }
        private void UpdateDaysLeft()
        {
            if (_isGuest || _licence == null) return;
            int d = _licence.DaysLeft;
            if (TxtDaysLeft == null) return;
            if (d <= 3)
            {
                TxtDaysLeft.Text        = d == 0 ? "EXPIRES TODAY" : $"{d}d left";
                TxtDaysLeft.Foreground  = Clr("#CC3D3D");
                LicenceCard.BorderBrush = Clr("#4A1010");
                LicenceCard.Background  = Clr("#0F0808");
                TxtLicenceLine1.Text    = "⚠ KEY EXPIRING SOON";
                TxtLicenceLine1.Foreground = Clr("#CC3D3D");
                if (BtnRenew != null) BtnRenew.Visibility = Visibility.Visible;
            }
            else
            {
                TxtDaysLeft.Text       = $"{d} days left";
                TxtDaysLeft.Foreground = Clr("#3DCC5F");
            }
        }
        private void StartExpiryWatcher()
        {
            _expiryTimer.Interval = TimeSpan.FromMinutes(1);
            _expiryTimer.Tick += (s, e) => UpdateDaysLeft();
            _expiryTimer.Start();
        }
        private void Renew_Click(object sender, RoutedEventArgs e)
            => Process.Start(new ProcessStartInfo("https://discord.gg/obsidianlabs") { UseShellExecute = true });

        // ─── DNS ──────────────────────────────────────────────────────
        private void CboDns_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CboDns == null || TxtDnsStatus == null || CustomDnsPanel == null) return;
            string tag = (CboDns.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "";
            CustomDnsPanel.Visibility = tag == "custom" ? Visibility.Visible : Visibility.Collapsed;
            if (tag != "custom") _activeDns = tag;
            TxtDnsStatus.Text = string.IsNullOrEmpty(tag) ? "System DNS — no changes" : tag == "custom" ? "Custom DNS — enter address above" : $"{tag} — active on connect";
        }
        private void ApplyCustomDns_Click(object sender, RoutedEventArgs e)
        {
            if (TxtCustomDns == null) return;
            string dns = TxtCustomDns.Text.Trim();
            if (string.IsNullOrEmpty(dns) || dns == "e.g. 9.9.9.9") return;
            _activeDns = dns;
            if (TxtDnsStatus != null) TxtDnsStatus.Text = $"Custom: {dns}";
            if (CustomDnsPanel != null) CustomDnsPanel.Visibility = Visibility.Collapsed;
        }

        // ─── SPEED TEST ───────────────────────────────────────────────
        private async void SpeedTest_Click(object sender, RoutedEventArgs e)
        {
            if (BtnSpeedTest == null) return;
            BtnSpeedTest.IsEnabled = false;
            SetStatus("Running speed test...", "#B43CFF");
            if (TxtDownload != null)  TxtDownload.Text  = "...";
            if (TxtUpload != null)    TxtUpload.Text    = "...";
            if (TxtSpeedPing != null) TxtSpeedPing.Text = "...";

            int latency = await DoPingAsync("1.1.1.1");
            if (TxtSpeedPing != null) TxtSpeedPing.Text = latency > 0 ? latency.ToString() : "---";

            double dl = 0;
            try
            {
                if (TxtSpeedStatus != null) TxtSpeedStatus.Text = "Testing download...";
                var sw    = Stopwatch.StartNew();
                var bytes = await Http.GetByteArrayAsync("https://speed.cloudflare.com/__down?bytes=5000000");
                sw.Stop();
                dl = Math.Round(bytes.Length / 1_000_000.0 * 8 / sw.Elapsed.TotalSeconds, 1);
                if (TxtDownload != null) TxtDownload.Text = dl.ToString();
            }
            catch { if (TxtDownload != null) TxtDownload.Text = "---"; }

            double ul = 0;
            try
            {
                if (TxtSpeedStatus != null) TxtSpeedStatus.Text = "Testing upload...";
                var data    = new byte[1_000_000];
                new Random().NextBytes(data);
                var sw      = Stopwatch.StartNew();
                await Http.PostAsync("https://speed.cloudflare.com/__up", new ByteArrayContent(data));
                sw.Stop();
                ul = Math.Round(1.0 * 8 / sw.Elapsed.TotalSeconds, 1);
                if (TxtUpload != null) TxtUpload.Text = ul.ToString();
            }
            catch { if (TxtUpload != null) TxtUpload.Text = "---"; }

            if (TxtSpeedStatus != null) TxtSpeedStatus.Text = $"Done — {dl} Mbps ↓  ·  {ul} Mbps ↑  ·  {latency}ms";
            BtnSpeedTest.IsEnabled = true;
            SetStatus("Speed test complete.", "#3DCC5F");
        }

        // ─── TRACEROUTE ───────────────────────────────────────────────
        private async void Trace_Click(object sender, RoutedEventArgs e)
        {
            if (BtnTrace == null || TraceList == null) return;
            BtnTrace.IsEnabled = false;
            TraceList.Items.Clear();
            string target = _connectedRegion != null
                ? Regions.First(r => r.Id == _connectedRegion).PingIp : "8.8.8.8";
            TraceList.Items.Add($"Tracing to {target}...");
            await Task.Run(async () =>
            {
                for (int ttl = 1; ttl <= 20; ttl++)
                {
                    try
                    {
                        using var p = new Ping();
                        var opts    = new PingOptions(ttl, true);
                        var sw      = Stopwatch.StartNew();
                        var reply   = await p.SendPingAsync(target, 3000, new byte[32], opts);
                        sw.Stop();
                        string hopIp = reply.Address?.ToString() ?? "*";
                        int    hopMs = (int)sw.ElapsedMilliseconds;
                        string stat  = reply.Status is IPStatus.TtlExpired or IPStatus.Success ? $"{hopMs}ms" : "  *";
                        string qual  = hopMs < 50 ? "✓" : hopMs < 100 ? "△" : "✗";
                        await Dispatcher.InvokeAsync(() => TraceList.Items.Add($"  {ttl,2}.  {hopIp,-18}  {stat,8}  {qual}"));
                        if (reply.Status == IPStatus.Success) break;
                    }
                    catch { await Dispatcher.InvokeAsync(() => TraceList.Items.Add($"  {ttl,2}.  *  (timeout)")); }
                }
                await Dispatcher.InvokeAsync(() => { TraceList.Items.Add("──────────────────────────────"); TraceList.Items.Add("✓  Trace complete."); BtnTrace.IsEnabled = true; });
            });
        }

        // ─── ISP INFO ────────────────────────────────────────────────
        private async void LoadIspInfo()
        {
            try
            {
                var resp = await Http.GetStringAsync("https://ipinfo.io/json");
                var json = JsonSerializer.Deserialize<JsonElement>(resp);
                string ip   = json.TryGetProperty("ip",      out var ipv)  ? ipv.GetString()  ?? "---" : "---";
                string isp  = json.TryGetProperty("org",     out var orgv) ? orgv.GetString() ?? "---" : "---";
                string city = json.TryGetProperty("city",    out var cv)   ? cv.GetString()   ?? "---" : "---";
                string ctry = json.TryGetProperty("country", out var cc)   ? cc.GetString()   ?? "---" : "---";
                if (isp.Length > 10 && isp.Contains(' ')) isp = string.Join(" ", isp.Split(' ').Skip(1));
                _cachedIp       = ip;
                _cachedIsp      = isp.Length > 18 ? isp[..18] + ".." : isp;
                _cachedLocation = $"{city}, {ctry}";
                if (!_streamerMode)
                {
                    if (TxtMyIP     != null) TxtMyIP.Text     = _cachedIp;
                    if (TxtISP      != null) TxtISP.Text      = _cachedIsp;
                    if (TxtLocation != null) TxtLocation.Text = _cachedLocation;
                }
            }
            catch { if (TxtMyIP != null) TxtMyIP.Text = TxtISP!.Text = TxtLocation!.Text = "---"; }
        }

        // ─── ROUTE DIAGRAM ────────────────────────────────────────────
        private void DrawRouteCanvas(string? regionId, bool connected)
        {
            if (RouteCanvas == null) return;
            RouteCanvas.Children.Clear();
            double W = RouteCanvas.ActualWidth  > 40 ? RouteCanvas.ActualWidth  : 620;
            double H = RouteCanvas.ActualHeight > 20 ? RouteCanvas.ActualHeight : 120;
            double xYou = 70, xSvr = W * 0.35, xRgn = W * 0.65, xGame = W - 70;
            double yMid = H / 2, yTop = H * 0.28, yBot = H * 0.72;
            var lineBrush = connected ? Clr("#3A1860") : Clr("#1A1030");
            var glowBrush = connected ? Clr("#B43CFF") : Clr("#2A1650");

            void DrawLine(double x1, double y1, double x2, double y2, bool glow = false)
            {
                RouteCanvas.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, StrokeThickness = glow ? 1.5 : 1, Stroke = glow ? glowBrush : lineBrush });
            }
            DrawLine(xYou, yMid, xSvr, yTop);
            DrawLine(xYou, yMid, xSvr, yBot);
            DrawLine(xSvr, yTop, xRgn, yMid, connected);
            DrawLine(xSvr, yBot, xRgn, yMid, connected);
            DrawLine(xRgn, yMid, xGame, yMid, connected);

            void DrawNode(double cx, double cy, string label, string sub, bool active)
            {
                double nw = 88, nh = 34;
                var bg = new Border
                {
                    Width = nw, Height = nh, CornerRadius = new CornerRadius(6),
                    Background = active ? Clr("#200A3C") : Clr("#0C0A18"),
                    BorderBrush = active ? Clr("#B43CFF") : Clr("#1A1028"),
                    BorderThickness = new Thickness(active ? 1.5 : 1)
                };
                Canvas.SetLeft(bg, cx - nw / 2); Canvas.SetTop(bg, cy - nh / 2);
                var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Center };
                sp.Children.Add(new TextBlock { Text = label, FontFamily = new FontFamily("Consolas"), FontSize = 11, FontWeight = FontWeights.Bold, Foreground = active ? Clr("#C4B8E8") : Clr("#7A6A9E"), HorizontalAlignment = HorizontalAlignment.Center });
                if (!string.IsNullOrEmpty(sub)) sp.Children.Add(new TextBlock { Text = sub, FontFamily = new FontFamily("Consolas"), FontSize = 10, Foreground = active ? Clr("#9A88C4") : Clr("#5A4878"), HorizontalAlignment = HorizontalAlignment.Center });
                bg.Child = sp;
                RouteCanvas.Children.Add(bg);
                if (active) { var dot = new Ellipse { Width = 8, Height = 8, Fill = Clr("#B43CFF") }; Canvas.SetLeft(dot, cx + nw / 2 - 12); Canvas.SetTop(dot, cy + nh / 2 - 12); RouteCanvas.Children.Add(dot); }
            }

            void DrawPingLbl(double cx, double cy, string ms)
            {
                var tb = new TextBlock { Text = ms, FontFamily = new FontFamily("Consolas"), FontSize = 11, FontWeight = FontWeights.Bold, Foreground = connected ? Clr("#9A88C4") : Clr("#3A2A50"), Background = Clr("#07060E") };
                Canvas.SetLeft(tb, cx - 16); Canvas.SetTop(tb, cy - 10);
                RouteCanvas.Children.Add(tb);
            }

            DrawNode(xYou, yMid, "YOU", "Your PC", true);
            DrawNode(xSvr, yTop, "Node 1", "Relay", connected);
            DrawNode(xSvr, yBot, "Node 2", "Relay", connected);
            string rName = regionId != null ? GetName(regionId) : "---";
            if (connected && _regionPings.TryGetValue(regionId!, out int pms) && pms > 0)
            {
                DrawPingLbl((xYou + xSvr) / 2, (yMid + yTop) / 2, $"{pms / 2}ms");
                DrawPingLbl((xYou + xSvr) / 2, (yMid + yBot) / 2, $"{pms / 2}ms");
                DrawPingLbl((xSvr + xRgn) / 2, yMid - 14, $"{pms}ms");
            }
            else { DrawPingLbl((xYou + xSvr) / 2, (yMid + yTop) / 2, "---"); DrawPingLbl((xYou + xSvr) / 2, (yMid + yBot) / 2, "---"); }
            DrawNode(xRgn, yMid, rName.Length > 9 ? rName[..9] : rName, "Server", connected);
            DrawNode(xGame, yMid, "GAME", "Server", connected);
        }

        private void DrawGameRouteCanvas(GameProfile game)
        {
            if (GameRouteCanvas == null) return;
            GameRouteCanvas.Children.Clear();
            double W = GameRouteCanvas.ActualWidth > 20 ? GameRouteCanvas.ActualWidth : 420;
            double H = GameRouteCanvas.ActualHeight > 20 ? GameRouteCanvas.ActualHeight : 74;
            double y = H / 2;
            double[] xs = { 45, W * 0.32, W * 0.62, W - 45 };
            string[] labels = { "YOU", "OPT NODE", GetName(game.BestRegion), game.Name.Length > 8 ? game.Name[..8] : game.Name };
            for (int i = 0; i < xs.Length - 1; i++)
                GameRouteCanvas.Children.Add(new Line { X1 = xs[i] + 36, Y1 = y, X2 = xs[i + 1] - 36, Y2 = y, Stroke = Clr("#2A1650"), StrokeThickness = 1 });
            foreach (var (x, lbl) in xs.Zip(labels))
            {
                var bg = new Border { Width = 72, Height = 28, CornerRadius = new CornerRadius(5), Background = Clr("#130E24"), BorderBrush = Clr("#2A1650"), BorderThickness = new Thickness(1) };
                Canvas.SetLeft(bg, x - 36); Canvas.SetTop(bg, y - 14);
                bg.Child = new TextBlock { Text = lbl, FontFamily = new FontFamily("Consolas"), FontSize = 11, FontWeight = FontWeights.Bold, Foreground = Clr("#9A88C4"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                GameRouteCanvas.Children.Add(bg);
            }
        }

        // ─── PING GRAPH ───────────────────────────────────────────────
        private void DrawGraph()
        {
            if (PingGraph == null) return;
            PingGraph.Children.Clear();
            if (_history.Count < 2) return;
            double w = PingGraph.ActualWidth, h = PingGraph.ActualHeight;
            if (w <= 0 || h <= 0) return;
            int maxV = Math.Max(200, _history.Max());
            for (int i = 1; i < _history.Count; i++)
            {
                double x1 = (i - 1) / (double)(MaxHist - 1) * w;
                double x2 = i       / (double)(MaxHist - 1) * w;
                double y1 = h - (_history[i - 1] / (double)maxV) * h;
                double y2 = h - (_history[i]     / (double)maxV) * h;
                PingGraph.Children.Add(new Line { X1 = x1, Y1 = y1, X2 = x2, Y2 = y2, StrokeThickness = 1.5, Stroke = PingBrush(_history[i]) });
                if (i == _history.Count - 1) { var dot = new Ellipse { Width = 6, Height = 6, Fill = PingBrush(_history[i]) }; Canvas.SetLeft(dot, x2 - 3); Canvas.SetTop(dot, y2 - 3); PingGraph.Children.Add(dot); }
            }
        }

        // ─── DNS HELPERS ─────────────────────────────────────────────
        private static async Task ApplyDnsAsync(string dns)
        {
            if (string.IsNullOrEmpty(dns)) return;
            try
            {
                var adapters = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                                (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet || n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                                !n.Description.Contains("Virtual") && !n.Description.Contains("Hyper-V") && !n.Description.Contains("VMware") && !n.Description.Contains("Loopback") && !n.Description.Contains("Bluetooth"));
                foreach (var a in adapters) await RunCmdAsync("netsh", $"interface ip set dns \"{a.Name}\" static {dns}");
            }
            catch { }
        }

        private static async Task ApplyDnsToAdapterAsync(string dns, string adapterName)
        {
            if (string.IsNullOrEmpty(dns)) return;
            try { if (!string.IsNullOrEmpty(adapterName)) await RunCmdAsync("netsh", $"interface ip set dns \"{adapterName}\" static {dns}"); else await ApplyDnsAsync(dns); } catch { }
        }

        private static async Task RestoreDnsAsync()
        {
            try
            {
                var adapters = NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                                (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet || n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                                !n.Description.Contains("Virtual") && !n.Description.Contains("Hyper-V") && !n.Description.Contains("VMware") && !n.Description.Contains("Loopback") && !n.Description.Contains("Bluetooth"));
                foreach (var a in adapters) await RunCmdAsync("netsh", $"interface ip set dns \"{a.Name}\" dhcp");
            }
            catch { }
        }

        private static async Task FlushDnsAsync() { try { await RunCmdAsync("ipconfig", "/flushdns"); } catch { } }

        private static void SetRegistryOpt(bool enable)
        {
            try
            {
                using var key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters", true);
                if (enable) { key?.SetValue("TcpNoDelay", 1); key?.SetValue("TcpAckFrequency", 1); } else { key?.DeleteValue("TcpNoDelay", false); key?.DeleteValue("TcpAckFrequency", false); }
            }
            catch { }
        }

        private static void SetRegistryValue(string path, string name, int value)
        {
            try { using var k = Registry.LocalMachine.OpenSubKey(path, true); k?.SetValue(name, value, RegistryValueKind.DWord); } catch { }
        }

        private static async Task RunCmdAsync(string exe, string args)
        {
            var p = new Process { StartInfo = new ProcessStartInfo(exe, args) { UseShellExecute = false, CreateNoWindow = true } };
            p.Start();
            await p.WaitForExitAsync();
        }

        // ─── PING HELPER ─────────────────────────────────────────────
        private static async Task<int> DoPingAsync(string ip)
        {
            try { var r = await new Ping().SendPingAsync(ip, 3000); return r.Status == IPStatus.Success ? (int)r.RoundtripTime : -1; }
            catch { return -1; }
        }

        // ─── LOADING BAR ─────────────────────────────────────────────
        private async Task AnimateLoadingBarAsync()
        {
            if (LoadingBar == null) return;
            double maxW = LoadingBar.ActualWidth > 0 ? LoadingBar.ActualWidth - 28 : 400;
            if (LoadingFill != null) LoadingFill.Width = 0;
            for (int i = 1; i <= 24; i++)
            {
                if (LoadingFill != null) LoadingFill.Width = maxW * (i / 24.0);
                await Task.Delay(28);
            }
        }

        // ─── RESIZE ──────────────────────────────────────────────────
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
        private void ResizeGrip_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton != System.Windows.Input.MouseButton.Left) return;
            e.Handled = true;
            SendMessage(new System.Windows.Interop.WindowInteropHelper(this).Handle, 0x112, (IntPtr)0xF008, IntPtr.Zero);
        }

        // ─── HELPERS ─────────────────────────────────────────────────
        private void SetStatus(string msg, string hex)
        {
            if (TxtStatus == null) return;
            TxtStatus.Text       = msg;
            TxtStatus.Foreground = Clr(hex);
        }

        private static string GetName(string id) => id switch
        {
            "US" => "US", "EU" => "EU", "ASIA" => "Asia Pacific", "BR" => "Brazil", "AU" => "Australia", _ => id
        };

        private static SolidColorBrush PingBrush(int ms)
        {
            if (ms < 0)   return RGB(0x7A, 0x6A, 0x9E);
            if (ms < 80)  return RGB(0x3D, 0xCC, 0x5F);
            if (ms < 150) return RGB(0xFF, 0xD7, 0x00);
            return RGB(0xCC, 0x3D, 0x3D);
        }

        private static SolidColorBrush RGB(byte r, byte g, byte b) => new(Color.FromRgb(r, g, b));
        private static SolidColorBrush Clr(string hex) => new((Color)ColorConverter.ConvertFromString(hex));

        // ─── AUTO REGION PICKER ──────────────────────────────────────
        private async void AutoRegion_Click(object sender, RoutedEventArgs e)
        {
            if (BtnAutoRegion != null) { BtnAutoRegion.IsEnabled = false; BtnAutoRegion.Content = "SCANNING..."; }
            if (TxtAutoRegionStatus != null) TxtAutoRegionStatus.Text = "Pinging all regions...";
            var results = new Dictionary<string, int>();
            foreach (var r in Regions)
            {
                try
                {
                    using var ping = new System.Net.NetworkInformation.Ping();
                    int total = 0; int success = 0;
                    for (int i = 0; i < 3; i++)
                    {
                        var reply = await Task.Run(() => ping.Send(r.PingIp, 2000));
                        if (reply.Status == System.Net.NetworkInformation.IPStatus.Success) { total += (int)reply.RoundtripTime; success++; }
                    }
                    results[r.Id] = success > 0 ? total / success : 9999;
                }
                catch { results[r.Id] = 9999; }
            }
            var best = results.OrderBy(kvp => kvp.Value).First();
            var bestRegion = Regions.First(r => r.Id == best.Key);
            _selectedRegion = best.Key;
            if (TxtAutoRegionStatus != null)
                TxtAutoRegionStatus.Text = $"Best: {bestRegion.Flag} {bestRegion.Name} — {best.Value}ms · Auto-selected!";
            SetStatus($"Auto Region Picker: {bestRegion.Name} selected ({best.Value}ms)", "#3DCC5F");
            if (BtnAutoRegion != null) { BtnAutoRegion.IsEnabled = true; BtnAutoRegion.Content = "▶  PICK BEST REGION"; }
        }

        // ─── GAME AUTO-DETECT ─────────────────────────────────────────
        private bool _autoDetectOn = false;
        private readonly DispatcherTimer _autoDetectTimer = new() { Interval = TimeSpan.FromSeconds(5) };
        private static readonly Dictionary<string, string> ProcessToGame = new(StringComparer.OrdinalIgnoreCase)
        {
            ["VALORANT-Win64-Shipping"] = "Valorant",
            ["csgo"]                    = "CS2",
            ["cs2"]                     = "CS2",
            ["FortniteClient-Win64-Shipping"] = "Fortnite",
            ["League of Legends"]       = "League of Legends",
            ["r5apex"]                  = "Apex Legends",
            ["GTA5"]                    = "GTA V / FiveM",
            ["javaw"]                   = "Minecraft",
            ["garena_gp"]               = "Free Fire",
            ["TslGame"]                 = "PUBG",
            ["Mobile Legends"]          = "Mobile Legends",
            ["cod"]                     = "Call of Duty",
        };

        private void AutoDetect_Click(object sender, RoutedEventArgs e)
        {
            _autoDetectOn = !_autoDetectOn;
            if (_autoDetectOn)
            {
                _autoDetectTimer.Tick += AutoDetect_Tick;
                _autoDetectTimer.Start();
                if (BtnAutoDetect    != null) BtnAutoDetect.Content = "DISABLE";
                if (TxtAutoDetectStatus != null) { TxtAutoDetectStatus.Text = "ENABLED — scanning for games every 5s"; TxtAutoDetectStatus.Foreground = Clr("#3DCC5F"); }
            }
            else
            {
                _autoDetectTimer.Stop();
                _autoDetectTimer.Tick -= AutoDetect_Tick;
                if (BtnAutoDetect    != null) BtnAutoDetect.Content = "ENABLE";
                if (TxtAutoDetectStatus != null) { TxtAutoDetectStatus.Text = "DISABLED"; TxtAutoDetectStatus.Foreground = Clr("#7A6A9E"); }
            }
        }

        private void AutoDetect_Tick(object? sender, EventArgs e)
        {
            try
            {
                var procs = System.Diagnostics.Process.GetProcesses().Select(p => p.ProcessName);
                foreach (var proc in procs)
                    if (ProcessToGame.TryGetValue(proc, out var gameName))
                    {
                        var profile = Games.FirstOrDefault(g => g.Name == gameName);
                        if (profile != null && _selectedGame?.Name != profile.Name)
                        {
                            _selectedGame   = profile;
                            _selectedRegion = profile.BestRegion;
                            _activeDns      = profile.Dns;
                            if (TxtAutoDetectStatus != null)
                                TxtAutoDetectStatus.Text = $"DETECTED: {profile.Emoji} {profile.Name} — profile applied";
                            SetStatus($"Auto-Detect: {profile.Name} detected, profile applied!", "#B43CFF");
                        }
                        return;
                    }
            }
            catch { }
        }

        // ─── PING COMPARE MODE ────────────────────────────────────────
        private void UpdatePingCompare()
        {
            if (_beforePing <= 0 || _history.Count == 0) return;
            int withPing = (int)_history.Average();
            int saved    = _beforePing - withPing;
            double pct   = Math.Round((double)saved / _beforePing * 100, 1);
            if (TxtCompareOff     != null) TxtCompareOff.Text     = _beforePing.ToString();
            if (TxtCompareOn      != null) TxtCompareOn.Text      = withPing.ToString();
            if (TxtCompareImprove != null) TxtCompareImprove.Text = saved > 0 ? $"+{pct}%" : $"{pct}%";
            if (TxtCompareSaved   != null) TxtCompareSaved.Text   = saved > 0 ? $"{saved}ms saved" : "no improvement yet";
        }

        // ─── SESSION REPORT CARD ─────────────────────────────────────
        private void UpdateReportCard()
        {
            if (TxtReportCard == null || _history.Count == 0) return;
            int avg   = (int)_history.Average();
            int best  = _sessionBest  == int.MaxValue ? 0 : _sessionBest;
            int worst = _sessionWorst;
            int saved = _beforePing > 0 ? _beforePing - avg : 0;
            double pct = _beforePing > 0 ? Math.Round((double)saved / _beforePing * 100, 1) : 0;
            var dur   = DateTime.UtcNow - _sessionStart;
            string region = _connectedRegion ?? "None";
            string game   = _selectedGame?.Name ?? "None";
            TxtReportCard.Text =
                $"p4inz Ping Reducer v5.6 — Session Report\n" +
                $"────────────────────────────────\n" +
                $"Game    : {game}\n" +
                $"Region  : {region}\n" +
                $"Duration: {(int)dur.TotalMinutes}m {dur.Seconds}s\n" +
                $"Avg Ping: {avg}ms    Best: {best}ms    Worst: {worst}ms\n" +
                $"Before  : {(_beforePing > 0 ? _beforePing + "ms" : "---")}\n" +
                $"Saved   : {(saved > 0 ? saved + "ms (" + pct + "% better)" : "---")}\n" +
                $"────────────────────────────────\n" +
                $"discord.gg/obsidianlabs";
        }

        private void CopyReport_Click(object sender, RoutedEventArgs e)
        {
            UpdateReportCard();
            if (TxtReportCard?.Text != null)
            {
                System.Windows.Clipboard.SetText(TxtReportCard.Text);
                SetStatus("Report card copied to clipboard — flex it!", "#3DCC5F");
            }
        }

        // ─── LEADERBOARD ─────────────────────────────────────────────
        private async void SubmitScore_Click(object sender, RoutedEventArgs e)
        {
            if (_history.Count == 0) { SetStatus("Connect and play first before submitting score.", "#FFD700"); return; }
            int avg   = (int)_history.Average();
            int saved = _beforePing > 0 ? _beforePing - avg : 0;
            string buyer = _licence?.Buyer ?? (_guest != null ? $"guest_{_guest.GuestId[..6]}" : "anonymous");
            try
            {
                if (TxtLeaderboardStatus != null) TxtLeaderboardStatus.Text = "Submitting...";
                var payload = System.Text.Json.JsonSerializer.Serialize(new { avgPing = avg, saved, game = _selectedGame?.Name ?? "None", updatedAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds() });
                var content = new StringContent(payload, System.Text.Encoding.UTF8, "application/json");
                string safeBuyer = Uri.EscapeDataString(buyer);
                await Http.PutAsync($"https://p4inz-exitlag-default-rtdb.firebaseio.com/leaderboard/{safeBuyer}.json", content);
                await LoadLeaderboard();
                SetStatus("Score submitted to leaderboard!", "#3DCC5F");
            }
            catch { if (TxtLeaderboardStatus != null) TxtLeaderboardStatus.Text = "Submit failed — check connection."; }
        }

        private async Task LoadLeaderboard()
        {
            try
            {
                var json = await Http.GetStringAsync("https://p4inz-exitlag-default-rtdb.firebaseio.com/leaderboard.json");
                var doc  = System.Text.Json.JsonDocument.Parse(json);
                var entries = new List<(string name, int avg, int saved)>();
                foreach (var prop in doc.RootElement.EnumerateObject())
                {
                    int avg   = prop.Value.TryGetProperty("avgPing", out var ap) ? ap.GetInt32() : 999;
                    int saved = prop.Value.TryGetProperty("saved",   out var sv) ? sv.GetInt32() : 0;
                    entries.Add((prop.Name, avg, saved));
                }
                entries.Sort((a, b) => a.avg.CompareTo(b.avg));
                if (LeaderboardList != null)
                {
                    LeaderboardList.Items.Clear();
                    for (int i = 0; i < Math.Min(entries.Count, 10); i++)
                    {
                        var e = entries[i];
                        string medal = i == 0 ? "🥇" : i == 1 ? "🥈" : i == 2 ? "🥉" : $"#{i+1}";
                        LeaderboardList.Items.Add($"{medal}  {e.name,-16} {e.avg}ms avg   +{e.saved}ms saved");
                    }
                }
                if (TxtLeaderboardStatus != null) TxtLeaderboardStatus.Text = $"Showing top {Math.Min(entries.Count, 10)} buyers — updated now.";
            }
            catch { if (TxtLeaderboardStatus != null) TxtLeaderboardStatus.Text = "Couldn't load leaderboard."; }
        }

        // ─── ANTI-LAG SHIELD ─────────────────────────────────────────
        private bool _antiLagOn = false;
        private async void AntiLag_Click(object sender, RoutedEventArgs e)
        {
            _antiLagOn = !_antiLagOn;
            if (_antiLagOn)
            {
                // Pause Windows Update, disable OneDrive sync, pause Steam
                try { await RunCmdAsync("sc", "stop wuauserv"); } catch { }
                try { await RunCmdAsync("taskkill", "/f /im OneDrive.exe"); } catch { }
                try { await RunCmdAsync("taskkill", "/f /im steam.exe"); } catch { }
                if (TxtAntiLagStatus != null) { TxtAntiLagStatus.Text = "ENABLED — Windows Update, OneDrive, Steam paused"; TxtAntiLagStatus.Foreground = Clr("#3DCC5F"); }
                if (BtnAntiLag      != null) BtnAntiLag.Content = "DISABLE";
                SetStatus("Anti-Lag Shield ON — background hogs paused.", "#3DCC5F");
            }
            else
            {
                try { await RunCmdAsync("sc", "start wuauserv"); } catch { }
                if (TxtAntiLagStatus != null) { TxtAntiLagStatus.Text = "DISABLED — background apps running normally"; TxtAntiLagStatus.Foreground = Clr("#7A6A9E"); }
                if (BtnAntiLag      != null) BtnAntiLag.Content = "ENABLE";
                SetStatus("Anti-Lag Shield OFF — services restored.", "#9A88C4");
            }
        }

        // ─── PACKET PRIORITY ─────────────────────────────────────────
        private bool _packetPriorityOn = false;
        private void PacketPriority_Click(object sender, RoutedEventArgs e)
        {
            _packetPriorityOn = !_packetPriorityOn;
            if (_packetPriorityOn)
            {
                if (_selectedGame != null)
                {
                    // Map game to process name
                    var procName = ProcessToGame.FirstOrDefault(kvp => kvp.Value == _selectedGame.Name).Key;
                    if (procName != null)
                        try
                        {
                            var procs = System.Diagnostics.Process.GetProcessesByName(procName);
                            foreach (var p in procs) p.PriorityClass = System.Diagnostics.ProcessPriorityClass.High;
                        }
                        catch { }
                }
                if (TxtPacketPriorityStatus != null) { TxtPacketPriorityStatus.Text = $"ENABLED — game process set to HIGH priority"; TxtPacketPriorityStatus.Foreground = Clr("#B43CFF"); }
                if (BtnPacketPriority      != null) BtnPacketPriority.Content = "DISABLE";
                SetStatus("Packet Priority ON — game set to High CPU/IO priority.", "#B43CFF");
            }
            else
            {
                if (TxtPacketPriorityStatus != null) { TxtPacketPriorityStatus.Text = "DISABLED"; TxtPacketPriorityStatus.Foreground = Clr("#7A6A9E"); }
                if (BtnPacketPriority      != null) BtnPacketPriority.Content = "ENABLE";
                SetStatus("Packet Priority OFF.", "#9A88C4");
            }
        }

        // ─── GAME SERVER STATUS ───────────────────────────────────────
        private async void RefreshServerStatus_Click(object sender, RoutedEventArgs e)
        {
            if (BtnRefreshServerStatus != null) BtnRefreshServerStatus.IsEnabled = false;
            if (TxtServerStatusTime != null) TxtServerStatusTime.Text = "Checking...";
            // Check game servers via ping to known IPs/domains
            await CheckServer(TxtStatusValorant,  "valorant.secure.dyn.riotcdn.net", "Valorant");
            await CheckServer(TxtStatusCS2,       "208.64.200.1",                    "CS2");
            await CheckServer(TxtStatusFortnite,  "fortnite-public-service-prod11.ol.epicgames.com", "Fortnite");
            await CheckServer(TxtStatusLeague,    "prodlogin.lol.riotgames.com",     "League of Legends");
            await CheckServer(TxtStatusApex,      "origin.com",                      "Apex Legends");
            await CheckServer(TxtStatusRoblox,    "www.roblox.com",                  "Roblox");
            await CheckServer(TxtStatusPubg,      "prod-live-matchmaker.pubg.com",   "PUBG");
            await CheckServer(TxtStatusFreeFire,  "ff.garena.com",                   "Free Fire");
            await CheckServer(TxtStatusMinecraft, "session.minecraft.net",           "Minecraft");
            await CheckServer(TxtStatusML,        "mla.mobilelegends.com",           "Mobile Legends");
            await CheckServer(TxtStatusCOD,       "www.callofduty.com",              "Call of Duty");
            await CheckServer(TxtStatusGTA,       "ros.rockstargames.com",           "GTA Online");
            if (TxtServerStatusTime != null) TxtServerStatusTime.Text = $"Last checked: {DateTime.Now:HH:mm:ss}";
            if (BtnRefreshServerStatus != null) BtnRefreshServerStatus.IsEnabled = true;
        }

        private async Task CheckServer(TextBlock? lbl, string host, string name)
        {
            if (lbl == null) return;
            try
            {
                using var ping = new System.Net.NetworkInformation.Ping();
                var reply = await Task.Run(() => ping.Send(host, 3000));
                bool up = reply.Status == System.Net.NetworkInformation.IPStatus.Success;
                lbl.Text       = up ? $"🟢  {name} — Online ({reply.RoundtripTime}ms)" : $"🔴  {name} — No response";
                lbl.Foreground = up ? Clr("#3DCC5F") : Clr("#CC3D3D");
            }
            catch
            {
                lbl.Text       = $"🟡  {name} — Unknown";
                lbl.Foreground = Clr("#FFD700");
            }
        }

        // ─── DISCORD RICH PRESENCE ────────────────────────────────────
        private bool _discordRPCOn = false;
        private System.IO.Pipes.NamedPipeClientStream? _discordPipe;

        private void DiscordRPC_Click(object sender, RoutedEventArgs e)
        {
            _discordRPCOn = !_discordRPCOn;
            if (_discordRPCOn)
            {
                if (BtnDiscordRPC      != null) BtnDiscordRPC.Content = "DISABLE";
                if (TxtDiscordRPCStatus != null) { TxtDiscordRPCStatus.Text = "ENABLED — updating Discord status"; TxtDiscordRPCStatus.Foreground = Clr("#7289DA"); }
                SetStatus("Discord RPC ON — ping stats visible in Discord.", "#7289DA");
                _ = DiscordRPCLoop();
            }
            else
            {
                if (BtnDiscordRPC      != null) BtnDiscordRPC.Content = "ENABLE";
                if (TxtDiscordRPCStatus != null) { TxtDiscordRPCStatus.Text = "DISABLED"; TxtDiscordRPCStatus.Foreground = Clr("#7A6A9E"); }
                SetStatus("Discord RPC OFF.", "#9A88C4");
                try { _discordPipe?.Close(); _discordPipe = null; } catch { }
            }
        }

        private async Task DiscordRPCLoop()
        {
            // Discord RPC uses named pipe discord-ipc-0
            try
            {
                _discordPipe = new System.IO.Pipes.NamedPipeClientStream(".", "discord-ipc-0",
                    System.IO.Pipes.PipeDirection.InOut, System.IO.Pipes.PipeOptions.Asynchronous);
                await _discordPipe.ConnectAsync(2000);

                while (_discordRPCOn && _discordPipe.IsConnected)
                {
                    int avg = _history.Count > 0 ? (int)_history.Average() : 0;
                    string region = _connectedRegion ?? "None";
                    string game   = _selectedGame?.Name ?? "Exit Lag";
                    // Build Discord RPC handshake + activity payload
                    string activity = System.Text.Json.JsonSerializer.Serialize(new
                    {
                        cmd = "SET_ACTIVITY",
                        args = new
                        {
                            pid = System.Diagnostics.Process.GetCurrentProcess().Id,
                            activity = new
                            {
                                state   = $"{region} · {avg}ms avg ping",
                                details = $"Playing {game}",
                                assets  = new { large_text = "p4inz Ping Reducer v5.6" }
                            }
                        },
                        nonce = Guid.NewGuid().ToString()
                    });
                    byte[] data = System.Text.Encoding.UTF8.GetBytes(activity);
                    byte[] header = new byte[8];
                    BitConverter.GetBytes(1).CopyTo(header, 0); // opcode 1 = frame
                    BitConverter.GetBytes(data.Length).CopyTo(header, 4);
                    await _discordPipe.WriteAsync(header);
                    await _discordPipe.WriteAsync(data);
                    await Task.Delay(15000); // Update every 15s
                }
            }
            catch { /* Discord not running — silent fail */ }
        }

        // ─── NETWORK PRESET PROFILES ──────────────────────────────────
        private async void PresetGaming_Click(object sender, RoutedEventArgs e)    => await ApplyPreset("Gaming");
        private async void PresetStreaming_Click(object sender, RoutedEventArgs e) => await ApplyPreset("Streaming");
        private async void PresetWork_Click(object sender, RoutedEventArgs e)      => await ApplyPreset("Work");

        private async Task ApplyPreset(string preset)
        {
            SetStatus($"Applying {preset} preset...", "#FFD700");
            switch (preset)
            {
                case "Gaming":
                    // DNS: Cloudflare | MTU: 1480 | High Performance | Kill background hogs
                    _activeDns = "1.1.1.1";
                    await ApplyDnsAsync("1.1.1.1");
                    await RunCmdAsync("netsh", "interface ipv4 set subinterface \"Ethernet\" mtu=1480 store=persistent");
                    await RunCmdAsync("powercfg", "/setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c");
                    await RunCmdAsync("sc", "stop wuauserv");
                    try { await RunCmdAsync("taskkill", "/f /im OneDrive.exe"); } catch { }
                    await RunCmdAsync("netsh", "int tcp set global autotuninglevel=highlyrestricted");
                    SetStatus("Gaming preset active — DNS 1.1.1.1 · MTU 1480 · High Perf · BG apps paused", "#3DCC5F");
                    break;
                case "Streaming":
                    // DNS: Google | MTU: 1500 | Balanced | Allow background
                    _activeDns = "8.8.8.8";
                    await ApplyDnsAsync("8.8.8.8");
                    await RunCmdAsync("netsh", "interface ipv4 set subinterface \"Ethernet\" mtu=1500 store=persistent");
                    await RunCmdAsync("powercfg", "/setactive 381b4222-f694-41f0-9685-ff5bb260df2e");
                    await RunCmdAsync("netsh", "int tcp set global autotuninglevel=normal");
                    SetStatus("Streaming preset active — DNS 8.8.8.8 · MTU 1500 · Balanced power", "#4080FF");
                    break;
                case "Work":
                    // DNS: Quad9 (secure) | MTU: 1500 | Power saver | Normal TCP
                    _activeDns = "9.9.9.9";
                    await ApplyDnsAsync("9.9.9.9");
                    await RunCmdAsync("netsh", "interface ipv4 set subinterface \"Ethernet\" mtu=1500 store=persistent");
                    await RunCmdAsync("powercfg", "/setactive a1841308-3541-4fab-bc81-f71556f20b4a");
                    SetStatus("Work preset active — Quad9 DNS (secure) · Power saver · Normal TCP", "#9A88C4");
                    break;
            }
            if (TxtActivePreset != null) { TxtActivePreset.Text = $"ACTIVE: {preset.ToUpper()} PRESET"; TxtActivePreset.Foreground = Clr(preset == "Gaming" ? "#3DCC5F" : preset == "Streaming" ? "#4080FF" : "#9A88C4"); }
        }

        // ─── SMART AUTO-SWITCH ────────────────────────────────────────
        private bool   _smartSwitchOn     = false;
        private int    _smartSpikeCount   = 0;
        private string? _lastAutoSwitchFrom = null;

        private void SmartSwitch_Click(object sender, RoutedEventArgs e)
        {
            _smartSwitchOn = !_smartSwitchOn;
            if (BtnSmartSwitch     != null) BtnSmartSwitch.Content = _smartSwitchOn ? "DISABLE" : "ENABLE";
            if (TxtSmartSwitchStatus != null)
            {
                TxtSmartSwitchStatus.Text       = _smartSwitchOn ? "ENABLED — watching for spikes" : "DISABLED";
                TxtSmartSwitchStatus.Foreground = Clr(_smartSwitchOn ? "#3DCC5F" : "#7A6A9E");
            }
            SetStatus(_smartSwitchOn ? "Smart Switch ON — auto-jumps region on 3 consecutive spikes." : "Smart Switch OFF.", _smartSwitchOn ? "#3DCC5F" : "#9A88C4");
        }

        private async Task CheckSmartSwitch(int ms)
        {
            if (!_smartSwitchOn || _connectedRegion == null) return;
            bool isSpiking = ms > _spikeThreshold || ms <= 0;
            if (isSpiking) _smartSpikeCount++;
            else           _smartSpikeCount = 0;
            if (_smartSpikeCount >= 3)
            {
                _smartSpikeCount = 0;
                _lastAutoSwitchFrom = _connectedRegion;
                var next = _regionPings
                    .Where(kvp => kvp.Key != _connectedRegion && kvp.Value > 0)
                    .OrderBy(kvp => kvp.Value)
                    .FirstOrDefault();
                if (next.Key != null)
                {
                    SetStatus($"Smart Switch: spike detected — jumping {_connectedRegion} → {next.Key} ({next.Value}ms)…", "#FFD700");
                    _selectedRegion = next.Key;
                    await DoConnectAsync(next.Key);
                    if (TxtSmartSwitchStatus != null)
                        TxtSmartSwitchStatus.Text = $"SWITCHED: {_lastAutoSwitchFrom} → {next.Key} — watching…";
                }
            }
        }

        // ─── ISP THROTTLE DETECTOR ────────────────────────────────────
        private async void DetectThrottle_Click(object sender, RoutedEventArgs e)
        {
            if (BtnDetectThrottle != null) BtnDetectThrottle.IsEnabled = false;
            if (TxtThrottleStatus != null) { TxtThrottleStatus.Text = "Analyzing ISP traffic…"; TxtThrottleStatus.Foreground = Clr("#FFD700"); }

            // Ping game IPs vs neutral IPs — big gap = ISP throttling game traffic
            var gameIps    = new[] { "1.1.1.1", "206.189.0.0", "104.21.0.0" };   // Cloudflare / game CDN range
            var neutralIps = new[] { "8.8.8.8", "9.9.9.9", "208.67.222.222" };   // Google/Quad9/OpenDNS

            int gamePing    = await AvgPingAsync(gameIps);
            int neutralPing = await AvgPingAsync(neutralIps);
            int diff        = gamePing - neutralPing;

            string result;
            string color;
            if (diff > 40)
            {
                result = $"⚠ THROTTLING DETECTED — Game CDN is {diff}ms slower than neutral IPs.\n  Your ISP is likely throttling gaming traffic.\n  Recommended: Enable Gaming preset + switch DNS to 1.1.1.1.";
                color  = "#CC3D3D";
            }
            else if (diff > 15)
            {
                result = $"🟡 POSSIBLE THROTTLING — Game CDN is {diff}ms slower than neutral.\n  May be mild ISP shaping. Try Gaming preset.";
                color  = "#FFD700";
            }
            else
            {
                result = $"✅ NO THROTTLING DETECTED — Game CDN within {diff}ms of neutral IPs.\n  Your ISP is not throttling gaming traffic.";
                color  = "#3DCC5F";
            }

            if (TxtThrottleStatus != null) { TxtThrottleStatus.Text = result; TxtThrottleStatus.Foreground = Clr(color); }
            if (BtnDetectThrottle != null) BtnDetectThrottle.IsEnabled = true;
        }

        private async Task<int> AvgPingAsync(string[] hosts)
        {
            int total = 0; int count = 0;
            foreach (var h in hosts)
                try
                {
                    using var p = new System.Net.NetworkInformation.Ping();
                    var r = await Task.Run(() => p.Send(h, 2000));
                    if (r.Status == System.Net.NetworkInformation.IPStatus.Success) { total += (int)r.RoundtripTime; count++; }
                }
                catch { }
            return count > 0 ? total / count : 999;
        }

        // ─── GPU BOOST MODE ───────────────────────────────────────────
        private bool _gpuBoostOn = false;
        private async void GpuBoost_Click(object sender, RoutedEventArgs e)
        {
            _gpuBoostOn = !_gpuBoostOn;
            if (_gpuBoostOn)
            {
                // Disable Xbox Game Bar + Game DVR
                try
                {
                    Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\System\GameConfigStore", "GameDVR_Enabled", 0);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", 0);
                }
                catch { }
                // Disable fullscreen optimizations globally
                try { Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\System\GameConfigStore", "GameDVR_FSEBehavior", 2); } catch { }
                // Set GPU priority for games via registry
                try
                {
                    Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                        "GPU Priority", 8, Microsoft.Win32.RegistryValueKind.DWord);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                        "Priority", 6, Microsoft.Win32.RegistryValueKind.DWord);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                        "Scheduling Category", "High", Microsoft.Win32.RegistryValueKind.String);
                }
                catch { }
                // Disable HAGS (Hardware Accelerated GPU Scheduling) notification conflicts
                await RunCmdAsync("powercfg", "/setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c");
                if (BtnGpuBoost     != null) BtnGpuBoost.Content = "DISABLE";
                if (TxtGpuBoostStatus != null) { TxtGpuBoostStatus.Text = "ENABLED — Xbox DVR off · GPU Priority 8 · Fullscreen optimizations off"; TxtGpuBoostStatus.Foreground = Clr("#B43CFF"); }
                SetStatus("GPU Boost ON — Xbox DVR killed, GPU priority maxed.", "#B43CFF");
            }
            else
            {
                // Restore defaults
                try
                {
                    Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 1);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_CURRENT_USER\System\GameConfigStore", "GameDVR_Enabled", 1);
                    Microsoft.Win32.Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                        "GPU Priority", 2, Microsoft.Win32.RegistryValueKind.DWord);
                }
                catch { }
                if (BtnGpuBoost     != null) BtnGpuBoost.Content = "ENABLE";
                if (TxtGpuBoostStatus != null) { TxtGpuBoostStatus.Text = "DISABLED"; TxtGpuBoostStatus.Foreground = Clr("#7A6A9E"); }
                SetStatus("GPU Boost OFF — settings restored.", "#9A88C4");
            }
        }

        // ─── PING GUARANTEE CARD ─────────────────────────────────────
        private void CheckPingGuarantee(int ms)
        {
            if (PingGuaranteeCard == null || _beforePing <= 0 || _history.Count < 10) return;
            int avg = (int)_history.Average();
            if (avg >= _beforePing)
            {
                // No improvement detected
                PingGuaranteeCard.Visibility = Visibility.Visible;
                if (TxtGuaranteeMsg != null)
                    TxtGuaranteeMsg.Text =
                        "No improvement detected yet. Try these:\n" +
                        "1. Switch to a different region below\n" +
                        "2. Enable Gaming Preset in Settings\n" +
                        "3. Run ISP Throttle Detector in Tools\n" +
                        "4. Change DNS to 1.1.1.1\n" +
                        "5. Close background apps (Steam, Discord overlay)";
            }
            else
            {
                PingGuaranteeCard.Visibility = Visibility.Collapsed;
            }
        }

        // ─── PING GRAPH SCREENSHOT EXPORT ────────────────────────────
        private void ExportPingScreenshot_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Render the stats panel to a bitmap
                var target = PanelStats as System.Windows.FrameworkElement ?? this;
                double w = target.ActualWidth;
                double h = target.ActualHeight;
                if (w <= 0 || h <= 0) { SetStatus("Open the Stats tab first, then export.", "#FFD700"); return; }

                var rtb = new System.Windows.Media.Imaging.RenderTargetBitmap(
                    (int)w, (int)h, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
                rtb.Render(target);

                var dlg = new Microsoft.Win32.SaveFileDialog
                {
                    Title      = "Save Ping Report Screenshot",
                    Filter     = "PNG Image|*.png",
                    FileName   = $"p4inz_pingreducer_{DateTime.Now:yyyyMMdd_HHmm}.png",
                    InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop)
                };
                if (dlg.ShowDialog() != true) return;

                var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(rtb));
                using var stream = System.IO.File.OpenWrite(dlg.FileName);
                encoder.Save(stream);

                SetStatus($"Screenshot saved to {System.IO.Path.GetFileName(dlg.FileName)} — flex it on Discord! 🔥", "#3DCC5F");

                // Also copy to clipboard for instant paste
                System.Windows.Clipboard.SetImage(rtb);
                SetStatus("Screenshot saved + copied to clipboard — paste anywhere!", "#3DCC5F");
            }
            catch (Exception ex) { SetStatus($"Screenshot failed: {ex.Message}", "#CC3D3D"); }
        }

        // ─── THEME SYSTEM ────────────────────────────────────────────────────
        private bool _themeInitialized = false;

        private void InitThemePanel()
        {
            if (ThemePresetPanel == null || _themeInitialized) return;
            _themeInitialized = true;
            ThemeManager.ThemeChanged += OnThemeChanged;
            BuildTabCustomizePanel();

            foreach (var preset in ThemePresets.All)
            {
                var p   = preset;
                var btn = new System.Windows.Controls.Button
                {
                    Width = 108, Height = 52,
                    Margin = new Thickness(0, 0, 8, 8),
                    Cursor = System.Windows.Input.Cursors.Hand,
                };
                var card = new Border
                {
                    CornerRadius    = new CornerRadius(8),
                    BorderThickness = new Thickness(ThemeManager.Current.Name == p.Name ? 1.5 : 1),
                    BorderBrush     = ThemeManager.Current.Name == p.Name ? Clr(p.Primary) : Clr("#1A1028"),
                    Background      = Clr("#0A0818"),
                };
                var inner = new StackPanel { Margin = new Thickness(6) };
                var swatch = new Border { Height = 8, CornerRadius = new CornerRadius(3), Margin = new Thickness(0,0,0,4) };
                if (p.Rainbow)
                {
                    var rb = new LinearGradientBrush { StartPoint = new System.Windows.Point(0,0), EndPoint = new System.Windows.Point(1,0) };
                    rb.GradientStops.Add(new GradientStop(Colors.Red,     0.0));
                    rb.GradientStops.Add(new GradientStop(Colors.Yellow,  0.25));
                    rb.GradientStops.Add(new GradientStop(Colors.Lime,    0.5));
                    rb.GradientStops.Add(new GradientStop(Colors.Cyan,    0.75));
                    rb.GradientStops.Add(new GradientStop(Colors.Magenta, 1.0));
                    swatch.Background = rb;
                }
                else
                {
                    var gb = new LinearGradientBrush { StartPoint = new System.Windows.Point(0,0), EndPoint = new System.Windows.Point(1,0) };
                    gb.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(p.Primary),   0));
                    gb.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(p.Secondary), 1));
                    swatch.Background = gb;
                }
                inner.Children.Add(swatch);
                inner.Children.Add(new System.Windows.Controls.TextBlock
                {
                    Text = p.Name, Foreground = Clr("#C4B8E8"),
                    FontFamily = new System.Windows.Media.FontFamily("Consolas"),
                    FontSize = 10, TextWrapping = System.Windows.TextWrapping.Wrap,
                });
                card.Child = inner;
                var tpl = new ControlTemplate(typeof(System.Windows.Controls.Button));
                tpl.VisualTree = new FrameworkElementFactory(typeof(ContentPresenter));
                btn.Template = tpl;
                btn.Content  = card;
                btn.Click   += (s, e) => { ThemeManager.Apply(p, Application.Current); SyncThemeInputs(); UpdatePresetHighlights(); };
                ThemePresetPanel.Children.Add(btn);
            }
            SyncThemeInputs();
        }

        private void SyncThemeInputs()
        {
            if (TxtPrimaryColor   != null) TxtPrimaryColor.Text   = ThemeManager.Current.Primary;
            if (TxtSecondaryColor != null) TxtSecondaryColor.Text = ThemeManager.Current.Secondary;
            if (TxtCardBgColor    != null) TxtCardBgColor.Text    = ThemeManager.Current.CardBg;
            if (BtnRainbow != null) BtnRainbow.Content = ThemeManager.Current.Rainbow ? "DISABLE" : "ENABLE";
            _rainbowOn = ThemeManager.Current.Rainbow;
            UpdateSwatches();
        }

        private void UpdateSwatches()
        {
            TrySetSwatch(SwatchPrimary,   TxtPrimaryColor?.Text   ?? ThemeManager.Current.Primary);
            TrySetSwatch(SwatchSecondary, TxtSecondaryColor?.Text ?? ThemeManager.Current.Secondary);
            TrySetSwatch(SwatchCardBg,    TxtCardBgColor?.Text    ?? ThemeManager.Current.CardBg);
            try
            {
                string p = TxtPrimaryColor?.Text   ?? ThemeManager.Current.Primary;
                string s = TxtSecondaryColor?.Text ?? ThemeManager.Current.Secondary;
                if (PreviewStop1 != null) PreviewStop1.Color = (Color)ColorConverter.ConvertFromString(p);
                if (PreviewStop2 != null) PreviewStop2.Color = (Color)ColorConverter.ConvertFromString(s);
            }
            catch { }
        }

        private void TrySetSwatch(Border? b, string hex)
        {
            if (b == null) return;
            try { b.Background = Clr(hex); } catch { }
        }

        private void UpdatePresetHighlights()
        {
            if (ThemePresetPanel == null) return;
            int idx = 0;
            foreach (System.Windows.Controls.Button btn in ThemePresetPanel.Children)
            {
                if (btn.Content is Border card && idx < ThemePresets.All.Count)
                {
                    bool active = ThemePresets.All[idx].Name == ThemeManager.Current.Name;
                    card.BorderBrush     = active ? Clr(ThemeManager.Current.Primary) : Clr("#1A1028");
                    card.BorderThickness = new Thickness(active ? 1.5 : 1);
                }
                idx++;
            }
        }

        private void OnThemeChanged()
        {
            try
            {
                if (SignalBarStop1 != null) SignalBarStop1.Color = (Color)ColorConverter.ConvertFromString(ThemeManager.Current.Primary);
                if (SignalBarStop2 != null) SignalBarStop2.Color = (Color)ColorConverter.ConvertFromString(ThemeManager.Current.Secondary);
            }
            catch { }
        }

        private System.Windows.Threading.DispatcherTimer? _colorDebounce;

        private void CustomColor_Changed(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            _colorDebounce?.Stop();
            _colorDebounce = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
            _colorDebounce.Tick += (s, ev) =>
            {
                _colorDebounce?.Stop();
                string primary = TxtPrimaryColor?.Text ?? ""; string secondary = TxtSecondaryColor?.Text ?? ""; string cardBg = TxtCardBgColor?.Text ?? "";
                try { ColorConverter.ConvertFromString(primary); } catch { return; }
                try { ColorConverter.ConvertFromString(secondary); } catch { return; }
                try { ColorConverter.ConvertFromString(cardBg); } catch { return; }
                var custom = new ThemeData { Name = "Custom", Primary = primary, Secondary = secondary, CardBg = cardBg, BaseBg = ThemeManager.Current.BaseBg, TextPrimary = ThemeManager.Current.TextPrimary, TextDim = ThemeManager.Current.TextDim, Rainbow = false };
                ThemeManager.Apply(custom, Application.Current);
                UpdatePresetHighlights();
            };
            _colorDebounce.Start();
            UpdateSwatches();
        }

        private void ResetPrimary_Click(object sender, RoutedEventArgs e)   { if (TxtPrimaryColor   != null) TxtPrimaryColor.Text   = "#B43CFF"; }
        private void ResetSecondary_Click(object sender, RoutedEventArgs e) { if (TxtSecondaryColor != null) TxtSecondaryColor.Text = "#CC2060"; }
        private void ResetCardBg_Click(object sender, RoutedEventArgs e)    { if (TxtCardBgColor    != null) TxtCardBgColor.Text    = "#0F0D1A"; }

        private bool _rainbowOn = false;
        private void Rainbow_Click(object sender, RoutedEventArgs e)
        {
            _rainbowOn = !_rainbowOn;
            if (BtnRainbow != null) BtnRainbow.Content = _rainbowOn ? "DISABLE" : "ENABLE";
            var theme = new ThemeData
            {
                Name = _rainbowOn ? "Rainbow" : "Custom",
                Primary = TxtPrimaryColor?.Text ?? ThemeManager.Current.Primary,
                Secondary = TxtSecondaryColor?.Text ?? ThemeManager.Current.Secondary,
                CardBg = TxtCardBgColor?.Text ?? ThemeManager.Current.CardBg,
                BaseBg = ThemeManager.Current.BaseBg, TextPrimary = ThemeManager.Current.TextPrimary,
                TextDim = ThemeManager.Current.TextDim, Rainbow = _rainbowOn, RainbowSpeed = GetRainbowSpeed(),
            };
            ThemeManager.Apply(theme, Application.Current);
            SetStatus(_rainbowOn ? "Rainbow mode ON 🌈" : "Rainbow mode OFF.", _rainbowOn ? "#B43CFF" : "#9A88C4");
        }

        private void RainbowSpeed_Changed(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (!_rainbowOn) return;
            var t = ThemeManager.Current; t.RainbowSpeed = GetRainbowSpeed();
            ThemeManager.Apply(t, Application.Current);
        }

        private int GetRainbowSpeed()
        {
            if (CboRainbowSpeed?.SelectedItem is System.Windows.Controls.ComboBoxItem item && item.Tag is string tag && int.TryParse(tag, out int s)) return s;
            return 3;
        }

        private void SaveCustomPreset_Click(object sender, RoutedEventArgs e)
        {
            ThemeManager.SaveLocal(ThemeManager.Current);
            SetStatus("Custom theme saved — loads automatically on next launch.", "#3DCC5F");
        }

        // ─── PULSE + SIGNAL BAR ──────────────────────────────────────
        private System.Windows.Media.Animation.Storyboard? _pulseStoryboard;

        private void StartConnectionPulse(bool on)
        {
            // Stop existing
            _pulseStoryboard?.Stop();

            if (ConnectDotCore != null)
                ConnectDotCore.Fill = Clr(on ? "#3DCC5F" : "#5A4878");
            if (ConnectPulseDot != null)
                ConnectPulseDot.Fill = Clr(on ? "#3DCC5F" : "#5A4878");

            if (!on || ConnectPulseDot == null) return;

            var sb = new System.Windows.Media.Animation.Storyboard();
            var fade = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 0.8, To = 0.0, Duration = TimeSpan.FromMilliseconds(900),
                AutoReverse = true,
                RepeatBehavior = System.Windows.Media.Animation.RepeatBehavior.Forever
            };
            var scale = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 1.0, To = 2.2, Duration = TimeSpan.FromMilliseconds(900),
                AutoReverse = true,
                RepeatBehavior = System.Windows.Media.Animation.RepeatBehavior.Forever
            };
            System.Windows.Media.Animation.Storyboard.SetTarget(fade, ConnectPulseDot);
            System.Windows.Media.Animation.Storyboard.SetTargetProperty(fade,
                new PropertyPath(UIElement.OpacityProperty));
            System.Windows.Media.Animation.Storyboard.SetTarget(scale, ConnectPulseDot);
            System.Windows.Media.Animation.Storyboard.SetTargetProperty(scale,
                new PropertyPath("(UIElement.RenderTransform).(ScaleTransform.ScaleX)"));

            ConnectPulseDot.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
            ConnectPulseDot.RenderTransform = new ScaleTransform(1, 1);

            var scaleY = new System.Windows.Media.Animation.DoubleAnimation
            {
                From = 1.0, To = 2.2, Duration = TimeSpan.FromMilliseconds(900),
                AutoReverse = true,
                RepeatBehavior = System.Windows.Media.Animation.RepeatBehavior.Forever
            };
            System.Windows.Media.Animation.Storyboard.SetTarget(scaleY, ConnectPulseDot);
            System.Windows.Media.Animation.Storyboard.SetTargetProperty(scaleY,
                new PropertyPath("(UIElement.RenderTransform).(ScaleTransform.ScaleY)"));

            sb.Children.Add(fade);
            sb.Children.Add(scale);
            sb.Children.Add(scaleY);
            sb.Begin();
            _pulseStoryboard = sb;
        }

        private void UpdateSignalBar(int ms)
        {
            if (SignalBar == null) return;
            // Map ping to bar width: 0ms = 140px full, 200ms+ = 0px
            const double maxWidth = 136;
            double width = ms <= 0 ? 0 : Math.Max(0, maxWidth - (ms / 200.0) * maxWidth);
            width = Math.Min(maxWidth, width);

            var anim = new System.Windows.Media.Animation.DoubleAnimation(width, TimeSpan.FromMilliseconds(300))
            { EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut } };
            SignalBar.BeginAnimation(FrameworkElement.WidthProperty, anim);
        }

        // ─── WINDOW ──────────────────────────────────────────────────
        private void UpgradeKey_GotFocus(object sender, System.Windows.RoutedEventArgs e)
        { if (TxtUpgradeKey?.Text == "P4NZ-XXXX-XXXX-XXXX") TxtUpgradeKey.Text = ""; }

        private void TitleBar_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        { if (e.ChangedButton == System.Windows.Input.MouseButton.Left) DragMove(); }
        private void MinBtn_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        private void CloseBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_fpsBoostOn) DisableFpsBoost();
            _pingTimer.Stop(); _expiryTimer.Stop(); _sessionTimer.Stop();
            Application.Current.Shutdown();
        }
    }
}
