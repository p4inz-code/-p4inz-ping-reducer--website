using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace ExitLag
{
    public partial class LoginWindow : Window
    {
        public KeyResult?  ValidatedResult { get; private set; }
        public GuestData?  GuestResult     { get; private set; }
        public bool        IsGuestMode     { get; private set; }
        private string     _pendingKey     = "";

        public LoginWindow()
        {
            InitializeComponent();
            _ = AutoUpdater.CheckAndPromptAsync();
            CheckReturningGuest();
            _ = TryAutoLoginAsync();
        }

        // ─── RETURNING GUEST CHECK ────────────────────────────────────────────
        private void CheckReturningGuest()
        {
            var existing = GuestSession.LoadLocal();
            if (existing == null) return;
            ReturningGuestBanner.Visibility = Visibility.Visible;
            string sessions = existing.SessionCount == 1 ? "1 session" : $"{existing.SessionCount} sessions";
            string game     = string.IsNullOrEmpty(existing.LastGame) ? "none yet" : existing.LastGame;
            string ping     = existing.BestPing < 9999 ? $"{existing.BestPing}ms" : "---";
            TxtReturningGuest.Text = $"{sessions} played  ·  Last: {game}  ·  Best ping: {ping}\nEnter your key above to unlock all features.";
        }

        // ─── AUTO LOGIN ───────────────────────────────────────────────────────
        private async Task TryAutoLoginAsync()
        {
            try
            {
                string? saved = KeyValidator.LoadKeyFile();
                if (saved == null) return;
                TxtKey.Text = saved;
                BtnActivate.IsEnabled = false;
                BtnGuest.IsEnabled    = false;
                SetStatus("Checking saved key...", "#FFD700");
                var result = await KeyValidator.ValidateAsync(saved);
                await HandleResult(result, saved);
            }
            catch { BtnActivate.IsEnabled = true; BtnGuest.IsEnabled = true; }
        }

        // ─── ACTIVATE KEY ─────────────────────────────────────────────────────
        private async void Activate_Click(object sender, RoutedEventArgs e)
        {
            string key = TxtKey.Text.Trim().ToUpper();
            if (key == "P4NZ-XXXX-XXXX-XXXX" || string.IsNullOrEmpty(key))
            { SetStatus("Enter your licence key first.", "#FFD700"); return; }
            BtnActivate.IsEnabled      = false;
            BtnGuest.IsEnabled         = false;
            BtnLogoutDevice.Visibility = Visibility.Collapsed;
            SetStatus("Validating key...", "#FFD700");
            var result = await KeyValidator.ValidateAsync(key);
            await HandleResult(result, key);
        }

        // ─── HANDLE KEY RESULT ────────────────────────────────────────────────
        private async Task HandleResult(KeyResult result, string key)
        {
            switch (result.Status)
            {
                case KeyStatus.Valid:
                    ValidatedResult = result;
                    KeyValidator.SaveKeyFile(key);
                    // Migrate guest history if same device was a guest
                    string? migrationMsg = await GuestSession.MigrateToKeyAsync(key);
                    if (migrationMsg != null)
                    { SetStatus($"Key verified! {migrationMsg}", "#3DCC5F"); await Task.Delay(2200); }
                    else
                    { SetStatus(result.Offline ? $"✓ {result.Message}" : "✓ Key verified!", "#3DCC5F"); await Task.Delay(600); }
                    OpenMain(isGuest: false);
                    break;

                case KeyStatus.WrongDevice:
                    _pendingKey                = key;
                    BtnLogoutDevice.Visibility = Visibility.Visible;
                    BtnActivate.IsEnabled      = true;
                    BtnGuest.IsEnabled         = true;
                    SetStatus("Key is active on another PC.\nClick below to log out that device.", "#FF8800");
                    break;

                case KeyStatus.NoInternet:
                    BtnActivate.IsEnabled = true;
                    BtnGuest.IsEnabled    = true;
                    SetStatus(result.Message, "#FFD700");
                    break;

                default:
                    KeyValidator.DeleteKeyFile();
                    TxtKey.Text           = "P4NZ-XXXX-XXXX-XXXX";
                    BtnActivate.IsEnabled = true;
                    BtnGuest.IsEnabled    = true;
                    SetStatus(result.Message, "#CC3D3D");
                    break;
            }
        }

        // ─── GUEST LOGIN ──────────────────────────────────────────────────────
        private async void Guest_Click(object sender, RoutedEventArgs e)
        {
            BtnGuest.IsEnabled    = false;
            BtnActivate.IsEnabled = false;
            SetStatus("Starting guest session...", "#7A6A9E");
            try
            {
                var guest = await GuestSession.StartAsync();
                GuestResult = guest;
                IsGuestMode = true;
                SetStatus($"Guest session started. Session #{guest.SessionCount}", "#9A88C4");
                await Task.Delay(500);
                OpenMain(isGuest: true);
            }
            catch (Exception ex)
            {
                SetStatus($"Failed: {ex.Message}", "#CC3D3D");
                BtnGuest.IsEnabled    = true;
                BtnActivate.IsEnabled = true;
            }
        }

        // ─── LOG OUT OTHER DEVICE ─────────────────────────────────────────────
        private async void LogoutDevice_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_pendingKey)) return;
            BtnLogoutDevice.IsEnabled = false;
            BtnActivate.IsEnabled     = false;
            BtnGuest.IsEnabled        = false;
            SetStatus("Logging out other device...", "#FFD700");
            bool ok = await KeyValidator.RequestDeviceTransferAsync(_pendingKey);
            if (!ok)
            {
                SetStatus("Failed. Check internet and try again.", "#CC3D3D");
                BtnLogoutDevice.IsEnabled = true;
                BtnActivate.IsEnabled     = true;
                BtnGuest.IsEnabled        = true;
                return;
            }
            SetStatus("Device logged out. Activating on this PC...", "#FFD700");
            await Task.Delay(800);
            var result = await KeyValidator.ValidateAsync(_pendingKey);
            BtnLogoutDevice.Visibility = Visibility.Collapsed;
            await HandleResult(result, _pendingKey);
        }

        // ─── OPEN MAIN ────────────────────────────────────────────────────────
        private void OpenMain(bool isGuest)
        {
            var main = isGuest
                ? new MainWindow(null,              GuestResult)
                : new MainWindow(ValidatedResult!,  null);
            main.Show();
            Close();
        }

        // ─── UI HELPERS ───────────────────────────────────────────────────────
        private void SetStatus(string msg, string hex)
        {
            TxtStatus.Text       = msg;
            TxtStatus.Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        }
        private void TxtKey_GotFocus(object sender, RoutedEventArgs e)
        { if (TxtKey.Text == "P4NZ-XXXX-XXXX-XXXX") TxtKey.Text = ""; }
        private void TxtKey_KeyDown(object sender, KeyEventArgs e)
        { if (e.Key == Key.Enter) Activate_Click(sender, e); }
        private void TitleBar_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        { if (e.ChangedButton == System.Windows.Input.MouseButton.Left) DragMove(); }
        private void CloseBtn_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();
    }
}
