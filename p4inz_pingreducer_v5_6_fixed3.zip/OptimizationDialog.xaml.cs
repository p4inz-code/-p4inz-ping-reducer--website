using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ExitLag
{
    public enum OptMode { None, Safe, Medium, Beast }

    public partial class OptimizationDialog : Window
    {
        public OptMode ChosenMode { get; private set; } = OptMode.None;

        private OptMode _selected = OptMode.Safe;
        private bool    _beastConfirmed = false;

        // Registry backup so we can fully restore on disconnect
        // Key = regPath|valueName, Value = original object
        public static readonly Dictionary<string, object?> RegBackup = new();

        public OptimizationDialog()
        {
            InitializeComponent();
            Loaded += (s, e) => SelectCard(OptMode.Safe);
        }

        // ─── CARD CLICKS ──────────────────────────────────────────────
        private void CardSafe_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
            => SelectCard(OptMode.Safe);
        private void CardMedium_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
            => SelectCard(OptMode.Medium);
        private void CardBeast_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
            => SelectCard(OptMode.Beast);

        private void SelectCard(OptMode mode)
        {
            _selected = mode;
            _beastConfirmed = false;
            if (ChkTick != null) ChkTick.Text = "";

            // Reset all cards
            SetCardStyle(CardSafe,   "#0C0A18", "#1A1028");
            SetCardStyle(CardMedium, "#0C0A18", "#1A1028");
            SetCardStyle(CardBeast,  "#0C0A18", "#1A1028");
            SetDot(DotSafe,   false, "#2A6A3A");
            SetDot(DotMedium, false, "#2A1650");
            SetDot(DotBeast,  false, "#2A1650");

            // Highlight selected
            switch (mode)
            {
                case OptMode.Safe:
                    SetCardStyle(CardSafe, "#091A0E", "#2A7A3A");
                    SetDot(DotSafe, true, "#3DCC5F");
                    ConfirmBtn.Content = "⚡  Apply Safe Mode";
                    SetBtnGradient("#1A6A3A", "#3DCC5F");
                    WarningBox.Visibility = Visibility.Collapsed;
                    break;
                case OptMode.Medium:
                    SetCardStyle(CardMedium, "#1A0A2A", "#B43CFF");
                    SetDot(DotMedium, true, "#B43CFF");
                    ConfirmBtn.Content = "⚡  Apply Medium Mode";
                    SetBtnGradient("#6A0ECC", "#B43CFF");
                    WarningBox.Visibility = Visibility.Collapsed;
                    break;
                case OptMode.Beast:
                    SetCardStyle(CardBeast, "#200808", "#CC3D3D");
                    SetDot(DotBeast, true, "#CC3D3D");
                    ConfirmBtn.Content = "🔥  Apply Beast Mode";
                    SetBtnGradient("#8A0808", "#CC3D3D");
                    WarningBox.Visibility = Visibility.Visible;
                    break;
            }

            UpdateConfirmEnabled();
        }

        private void SetCardStyle(Border card, string bg, string border)
        {
            if (card == null) return;
            card.Background   = Clr(bg);
            card.BorderBrush  = Clr(border);
        }

        private void SetDot(Border dot, bool active, string color)
        {
            if (dot == null) return;
            dot.BorderBrush = Clr(color);
            dot.Background  = active ? Clr(color) : Brushes.Transparent;
            dot.Opacity     = active ? 1.0 : 0.4;
        }

        private void SetBtnGradient(string c1, string c2)
        {
            var grad = new LinearGradientBrush();
            grad.StartPoint = new System.Windows.Point(0, 0);
            grad.EndPoint   = new System.Windows.Point(1, 0);
            grad.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(c1), 0));
            grad.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(c2), 1));
            ConfirmBtn.Background = grad;
        }

        private void UpdateConfirmEnabled()
        {
            if (ConfirmBtn == null) return;
            ConfirmBtn.IsEnabled = _selected != OptMode.Beast || _beastConfirmed;
        }

        // ─── BEAST CHECKBOX ───────────────────────────────────────────
        private void Chk_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            _beastConfirmed = !_beastConfirmed;
            if (ChkTick != null)   ChkTick.Text = _beastConfirmed ? "✓" : "";
            if (ChkBorder != null) ChkBorder.Background = _beastConfirmed ? Clr("#4A1010") : Clr("#1A0808");
            UpdateConfirmEnabled();
        }

        // ─── CONFIRM ──────────────────────────────────────────────────
        private void ConfirmBtn_Click(object sender, RoutedEventArgs e)
        {
            ChosenMode = _selected;
            DialogResult = true;
            Close();
        }

        private void CancelBtn_Click(object sender, RoutedEventArgs e)
        {
            ChosenMode = OptMode.None;
            DialogResult = false;
            Close();
        }

        private void TitleBar_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        { if (e.ChangedButton == System.Windows.Input.MouseButton.Left) DragMove(); }

        // ─── STATIC: APPLY OPTIMIZATION ──────────────────────────────
        // Called from MainWindow after user confirms mode
        public static async Task ApplyAsync(OptMode mode, string adapterName)
        {
            RegBackup.Clear();

            if (mode >= OptMode.Safe)
                await ApplySafeAsync(adapterName);

            if (mode >= OptMode.Medium)
                await ApplyMediumAsync(adapterName);

            if (mode >= OptMode.Beast)
                await ApplyBeastAsync(adapterName);
        }

        // ─── SAFE ─────────────────────────────────────────────────────
        // DNS warm-up: pre-resolve common game endpoints so cache is hot before game launch
        private static async Task ApplySafeAsync(string adapterName)
        {
            // Warm up DNS cache by resolving real game server hostnames
            string[] warmHosts =
            {
                "prod.ol.epicgames.com",     // Fortnite
                "valorant.secure.dyn.riotgames.com",
                "cfx-node1-1.prod.cfx.re",   // FiveM
                "mc.hypixel.net",
                "a.ns.roblox.com",
                "api.riotgames.com",
                "qa.cdn.riotgames.com",
            };
            var tasks = new List<Task>();
            foreach (var h in warmHosts)
                tasks.Add(Task.Run(async () => {
                    try { await System.Net.Dns.GetHostAddressesAsync(h); } catch { }
                }));
            await Task.WhenAll(tasks);
        }

        // ─── MEDIUM ───────────────────────────────────────────────────
        private static async Task ApplyMediumAsync(string adapterName)
        {
            // 1. Disable Nagle algorithm — reduces latency for small packets (critical for gaming)
            BackupReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces",
                      "TcpAckFrequency", null);
            BackupReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces",
                      "TCPNoDelay", null);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
                       "TcpAckFrequency", 1, Microsoft.Win32.RegistryValueKind.DWord);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
                       "TCPNoDelay", 1, Microsoft.Win32.RegistryValueKind.DWord);

            // 2. Remove Windows network throttling (removes 10-packet-per-interrupt CPU governor)
            BackupReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                      "NetworkThrottlingIndex", 10);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                       "NetworkThrottlingIndex", 0xFFFFFFFF, Microsoft.Win32.RegistryValueKind.DWord);

            // 3. System responsiveness — prioritize foreground app (game) over background services
            BackupReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                      "SystemResponsiveness", 20);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile",
                       "SystemResponsiveness", 0, Microsoft.Win32.RegistryValueKind.DWord);

            // 4. Game scheduling priority for known game processes
            BackupReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                      "GPU Priority", 2);
            BackupReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                      "Priority", 2);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                       "GPU Priority", 8, Microsoft.Win32.RegistryValueKind.DWord);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games",
                       "Priority", 6, Microsoft.Win32.RegistryValueKind.DWord);

            await Task.CompletedTask;
        }

        // ─── BEAST ────────────────────────────────────────────────────
        private static async Task ApplyBeastAsync(string adapterName)
        {
            // 1. Windows autotuning to restricted (reduces buffer bloat aggressively)
            await RunCmdAsync("netsh", "int tcp set global autotuninglevel=restricted");

            // 2. Enable RSS on active adapter (distributes packet processing across CPU cores)
            await RunCmdAsync("netsh", $"int tcp set supplemental Internet congestionprovider=ctcp");
            if (!string.IsNullOrEmpty(adapterName))
                await RunCmdAsync("netsh", $"int tcp set heuristics disabled");

            // 3. IRPStackSize — more simultaneous network I/O requests
            BackupReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters",
                      "IRPStackSize", 15);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters",
                       "IRPStackSize", 32, Microsoft.Win32.RegistryValueKind.DWord);

            // 4. Max connections per server
            BackupReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MAXCONNECTIONSPERSERVER",
                      "iexplore.exe", 10);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_MAXCONNECTIONSPERSERVER",
                       "iexplore.exe", 20, Microsoft.Win32.RegistryValueKind.DWord);

            // 5. QoS — mark all outbound as high priority (DSCP 46 = Expedited Forwarding)
            BackupReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
                      "DisableUserTOSSetting", 1);
            SafeSetReg(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters",
                       "DisableUserTOSSetting", 0, Microsoft.Win32.RegistryValueKind.DWord);
        }

        // ─── STATIC: RESTORE ALL ──────────────────────────────────────
        public static async Task RestoreAsync(OptMode mode)
        {
            if (mode == OptMode.None) return;

            // Restore registry backup
            foreach (var kvp in RegBackup)
            {
                try
                {
                    var parts = kvp.Key.Split('|');
                    if (parts.Length != 2) continue;
                    string path = parts[0], name = parts[1];
                    if (kvp.Value == null)
                        DeleteRegValue(path, name);
                    else
                        Microsoft.Win32.Registry.SetValue(path, name, kvp.Value);
                }
                catch { }
            }
            RegBackup.Clear();

            // Restore Beast netsh changes
            if (mode >= OptMode.Beast)
            {
                await RunCmdAsync("netsh", "int tcp set global autotuninglevel=normal");
                await RunCmdAsync("netsh", "int tcp set supplemental Internet congestionprovider=default");
                await RunCmdAsync("netsh", "int tcp set heuristics enabled");
            }

            await Task.CompletedTask;
        }

        // ─── REGISTRY HELPERS ─────────────────────────────────────────
        private static void BackupReg(string path, string name, object? defaultVal)
        {
            string key = $"{path}|{name}";
            if (RegBackup.ContainsKey(key)) return;
            try
            {
                var val = Microsoft.Win32.Registry.GetValue(path, name, defaultVal);
                RegBackup[key] = val;
            }
            catch { RegBackup[key] = defaultVal; }
        }

        private static void SafeSetReg(string path, string name, object value, Microsoft.Win32.RegistryValueKind kind)
        {
            try { Microsoft.Win32.Registry.SetValue(path, name, value, kind); } catch { }
        }

        private static void DeleteRegValue(string path, string name)
        {
            try
            {
                // parse hive manually
                var idx    = path.IndexOf('\\');
                var hive   = path[..idx];
                var sub    = path[(idx + 1)..];
                var root   = hive switch
                {
                    "HKEY_LOCAL_MACHINE" => Microsoft.Win32.Registry.LocalMachine,
                    "HKEY_CURRENT_USER"  => Microsoft.Win32.Registry.CurrentUser,
                    _ => null
                };
                root?.OpenSubKey(sub, true)?.DeleteValue(name, false);
            }
            catch { }
        }

        private static async Task RunCmdAsync(string exe, string args)
        {
            try
            {
                var p = new Process
                {
                    StartInfo = new ProcessStartInfo(exe, args)
                    {
                        UseShellExecute  = false,
                        CreateNoWindow   = true,
                        Verb             = "runas"
                    }
                };
                p.Start();
                await p.WaitForExitAsync();
            }
            catch { }
        }

        // ─── HELPERS ──────────────────────────────────────────────────
        public static string GetBestAdapter()
        {
            try
            {
                return NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                                (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                                 n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211) &&
                                !n.Description.Contains("Virtual") &&
                                !n.Description.Contains("Hyper-V") &&
                                !n.Description.Contains("VMware") &&
                                !n.Description.Contains("Loopback") &&
                                !n.Description.Contains("Bluetooth"))
                    .OrderByDescending(n => n.Speed)
                    .FirstOrDefault()?.Name ?? "";
            }
            catch { return ""; }
        }

        private static SolidColorBrush Clr(string hex)
            => new((Color)ColorConverter.ConvertFromString(hex));
    }
}
