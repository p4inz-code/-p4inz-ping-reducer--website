using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;

namespace ExitLag
{
    // ─── THEME DATA ───────────────────────────────────────────────────────────
    public class ThemeData
    {
        public string Name        { get; set; } = "Obsidian Purple";
        public string Primary     { get; set; } = "#B43CFF";   // main accent — buttons, glows, borders
        public string Secondary   { get; set; } = "#CC2060";   // gradient end — crimson by default
        public string CardBg      { get; set; } = "#0F0D1A";   // card backgrounds
        public string BaseBg      { get; set; } = "#09090F";   // window background
        public string TextPrimary { get; set; } = "#F0ECFF";   // main text
        public string TextDim     { get; set; } = "#7A6A9E";   // dimmed labels
        public bool   Rainbow     { get; set; } = false;       // animated rainbow mode
        public int    RainbowSpeed{ get; set; } = 3;           // seconds per cycle
    }

    // ─── PRESET LIBRARY ───────────────────────────────────────────────────────
    public static class ThemePresets
    {
        public static readonly List<ThemeData> All = new()
        {
            new() { Name = "Obsidian Purple", Primary = "#B43CFF", Secondary = "#CC2060", CardBg = "#0F0D1A", BaseBg = "#09090F", TextPrimary = "#F0ECFF", TextDim = "#7A6A9E" },
            new() { Name = "Crimson Blade",   Primary = "#FF2244", Secondary = "#FF6600", CardBg = "#140808", BaseBg = "#0A0707", TextPrimary = "#FFE8E8", TextDim = "#8A4A4A" },
            new() { Name = "Ocean Blue",      Primary = "#00AAFF", Secondary = "#0044CC", CardBg = "#07101A", BaseBg = "#07090F", TextPrimary = "#E0F0FF", TextDim = "#4A6A8A" },
            new() { Name = "Matrix Green",    Primary = "#00FF88", Secondary = "#00AA44", CardBg = "#070E0A", BaseBg = "#060C08", TextPrimary = "#D0FFE8", TextDim = "#2A6A44" },
            new() { Name = "Solar Gold",      Primary = "#FFB800", Secondary = "#FF6600", CardBg = "#120E00", BaseBg = "#0A0900", TextPrimary = "#FFF8D0", TextDim = "#8A7040" },
            new() { Name = "Pink Sakura",     Primary = "#FF44AA", Secondary = "#AA00FF", CardBg = "#140A14", BaseBg = "#0A070E", TextPrimary = "#FFE0F8", TextDim = "#8A4A7A" },
            new() { Name = "Cyber Teal",      Primary = "#00FFCC", Secondary = "#0088AA", CardBg = "#071212", BaseBg = "#060A0A", TextPrimary = "#D0FFF8", TextDim = "#2A7A6A" },
            new() { Name = "White Ice",       Primary = "#CCDDFF", Secondary = "#8899CC", CardBg = "#0E0E18", BaseBg = "#09090F", TextPrimary = "#FFFFFF", TextDim = "#8888AA" },
            new() { Name = "Rainbow",         Primary = "#FF4444", Secondary = "#FF8800", CardBg = "#0F0D1A", BaseBg = "#09090F", TextPrimary = "#F0ECFF", TextDim = "#7A6A9E", Rainbow = true, RainbowSpeed = 3 },
        };
    }

    // ─── THEME MANAGER ────────────────────────────────────────────────────────
    public static class ThemeManager
    {
        private static readonly string ThemeFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "p4inz", "pingreducer_theme.json");

        // Live theme — other classes read from this
        public static ThemeData Current { get; private set; } = ThemePresets.All[0];

        // Rainbow animation timer
        private static DispatcherTimer? _rainbowTimer;
        private static double           _rainbowHue = 0;

        // Fired whenever theme changes — MainWindow subscribes to update dynamic elements
        public static event Action? ThemeChanged;

        // ─── APPLY THEME ──────────────────────────────────────────────
        public static void Apply(ThemeData theme, Application app)
        {
            Current = theme;
            SaveLocal(theme);

            StopRainbow();

            var res = app.Resources;

            // Write WPF resource dictionary — all dynamic colors
            SetColor(res, "ThemePrimary",     theme.Primary);
            SetColor(res, "ThemeSecondary",   theme.Secondary);
            SetColor(res, "ThemeCardBg",      theme.CardBg);
            SetColor(res, "ThemeBaseBg",      theme.BaseBg);
            SetColor(res, "ThemeTextPrimary", theme.TextPrimary);
            SetColor(res, "ThemeTextDim",     theme.TextDim);

            // ── NEW keys — match App.xaml resource declarations ──────
            // Accent colors
            SetColor(res, "AccentPrimary",   theme.Primary);
            SetColor(res, "AccentSecondary", theme.Secondary);
            SetColor(res, "AccentLight",     LightenHex(theme.Primary,  0.15));
            SetColor(res, "AccentDark",      DarkenHex(theme.Primary,   0.25));
            SetColor(res, "AccentBold",      DarkenHex(theme.Primary,   0.12));
            SetColor(res, "AccentDim",       DarkenHex(theme.Primary,   0.65));
            SetColor(res, "AccentMid",       DarkenHex(theme.Primary,   0.45));
            SetColor(res, "AccentDeep",      DarkenHex(theme.Primary,   0.75));
            SetColor(res, "AccentShadow",    DarkenHex(theme.Primary,   0.80));
            SetColor(res, "AccentVoid",      DarkenHex(theme.Primary,   0.85));
            // Backgrounds
            SetColor(res, "BgBase",     theme.BaseBg);
            SetColor(res, "BgBaseDark", DarkenHex(theme.BaseBg,  0.15));
            SetColor(res, "BgDeep",     DarkenHex(theme.BaseBg,  0.30));
            SetColor(res, "BgCard",     theme.CardBg);
            SetColor(res, "BgCardMid",  LightenHex(theme.CardBg, 0.08));
            SetColor(res, "BgSuccessSubtle", "#0A1A0A");
            SetColor(res, "BgNeutral",       "#1A1A00");
            // Borders — derived from primary accent
            SetColor(res, "BorderSubtle", BlendHex(theme.BaseBg, theme.Primary, 0.18));
            SetColor(res, "BorderAccent", BlendHex(theme.BaseBg, theme.Primary, 0.38));
            // Text
            SetColor(res, "TextPrimary",   theme.TextPrimary);
            SetColor(res, "TextSecondary", BlendHex(theme.Primary, theme.TextPrimary, 0.30));
            SetColor(res, "TextLabel",     BlendHex(theme.Primary, theme.TextPrimary, 0.55));
            SetColor(res, "TextMuted",     BlendHex(theme.Primary, theme.TextPrimary, 0.72));
            SetColor(res, "TextDim",       BlendHex(theme.Primary, theme.BaseBg,      0.35));

            // Old keys kept for backward compat
            SetGradient(res, "ThemeGradientBrush",  theme.Primary, theme.Secondary);
            SetGradient(res, "ThemeBorderGradient", theme.Primary, theme.Secondary);
            SetSolid(res, "ThemePrimaryBrush",      theme.Primary);
            SetSolid(res, "ThemeSecondaryBrush",    theme.Secondary);
            SetSolid(res, "ThemeCardBgBrush",       theme.CardBg);
            SetSolid(res, "ThemeBaseBgBrush",       theme.BaseBg);
            SetSolid(res, "ThemeTextPrimaryBrush",  theme.TextPrimary);
            SetSolid(res, "ThemeTextDimBrush",      theme.TextDim);

            if (theme.Rainbow) StartRainbow(app, theme.RainbowSpeed);
            ThemeChanged?.Invoke();
        }

        // ─── LOAD + AUTO-APPLY ────────────────────────────────────────
        public static void LoadAndApply(Application app)
        {
            var saved = LoadLocal();
            Apply(saved ?? ThemePresets.All[0], app);
        }

        // ─── RAINBOW MODE ─────────────────────────────────────────────
        private static void StartRainbow(Application app, int speedSeconds)
        {
            _rainbowHue   = 0;
            _rainbowTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(50)
            };
            double step = 360.0 / (speedSeconds * 20); // 20 ticks/second
            _rainbowTimer.Tick += (s, e) =>
            {
                _rainbowHue = (_rainbowHue + step) % 360;
                double hue2 = (_rainbowHue + 120) % 360;

                string primary   = HslToHex(_rainbowHue, 1.0, 0.65);
                string secondary = HslToHex(hue2,        1.0, 0.55);

                SetGradient(app.Resources, "ThemeGradientBrush",  primary, secondary);
                SetGradient(app.Resources, "ThemeBorderGradient", primary, secondary);
                SetSolid(app.Resources, "ThemePrimaryBrush",   primary);
                SetSolid(app.Resources, "ThemeSecondaryBrush", secondary);
                SetColor(app.Resources, "ThemePrimary",        primary);
                SetColor(app.Resources, "ThemeSecondary",      secondary);
                // New resource keys
                SetColor(app.Resources, "AccentPrimary",   primary);
                SetColor(app.Resources, "AccentSecondary", secondary);
                SetColor(app.Resources, "AccentLight",  LightenHex(primary, 0.15));
                SetColor(app.Resources, "AccentDark",   DarkenHex(primary,  0.25));
                SetColor(app.Resources, "AccentBold",   DarkenHex(primary,  0.12));
                SetColor(app.Resources, "AccentDim",    DarkenHex(primary,  0.65));
                SetColor(app.Resources, "AccentMid",    DarkenHex(primary,  0.45));
                SetColor(app.Resources, "BorderSubtle", BlendHex(Current.BaseBg, primary, 0.18));
                SetColor(app.Resources, "BorderAccent", BlendHex(Current.BaseBg, primary, 0.38));
                SetColor(app.Resources, "TextSecondary", BlendHex(primary, Current.TextPrimary, 0.30));
                SetColor(app.Resources, "TextLabel",     BlendHex(primary, Current.TextPrimary, 0.55));
                SetColor(app.Resources, "TextMuted",     BlendHex(primary, Current.TextPrimary, 0.72));
                ThemeChanged?.Invoke();
            };
            _rainbowTimer.Start();
        }

        private static void StopRainbow()
        {
            _rainbowTimer?.Stop();
            _rainbowTimer = null;
        }

        // ─── PERSISTENCE ──────────────────────────────────────────────
        public static void SaveLocal(ThemeData theme)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ThemeFile)!);
                File.WriteAllText(ThemeFile, JsonSerializer.Serialize(theme));
            }
            catch { }
        }

        public static ThemeData? LoadLocal()
        {
            try
            {
                if (!File.Exists(ThemeFile)) return null;
                return JsonSerializer.Deserialize<ThemeData>(File.ReadAllText(ThemeFile));
            }
            catch { return null; }
        }

        // ─── COLOR MATH HELPERS ───────────────────────────────────────
        private static void SetColor(ResourceDictionary res, string key, string hex)
        {
            try { res[key] = (Color)ColorConverter.ConvertFromString(hex); } catch { }
        }

        private static void SetSolid(ResourceDictionary res, string key, string hex)
        {
            try { res[key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex)); } catch { }
        }

        private static void SetGradient(ResourceDictionary res, string key, string hex1, string hex2)
        {
            try
            {
                var brush = new LinearGradientBrush
                {
                    StartPoint = new Point(0, 0),
                    EndPoint   = new Point(1, 0)
                };
                brush.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(hex1), 0));
                brush.GradientStops.Add(new GradientStop((Color)ColorConverter.ConvertFromString(hex2), 1));
                res[key] = brush;
            }
            catch { }
        }

        // ─── HSL → HEX ────────────────────────────────────────────────
        public static string HslToHex(double h, double s, double l)
        {
            double c  = (1 - Math.Abs(2 * l - 1)) * s;
            double x  = c * (1 - Math.Abs((h / 60) % 2 - 1));
            double m  = l - c / 2;
            double r1, g1, b1;

            if      (h < 60)  { r1 = c; g1 = x; b1 = 0; }
            else if (h < 120) { r1 = x; g1 = c; b1 = 0; }
            else if (h < 180) { r1 = 0; g1 = c; b1 = x; }
            else if (h < 240) { r1 = 0; g1 = x; b1 = c; }
            else if (h < 300) { r1 = x; g1 = 0; b1 = c; }
            else              { r1 = c; g1 = 0; b1 = x; }

            int r = (int)Math.Round((r1 + m) * 255);
            int g = (int)Math.Round((g1 + m) * 255);
            int b = (int)Math.Round((b1 + m) * 255);
            return $"#{r:X2}{g:X2}{b:X2}";
        }

        // Helper for MainWindow to get current hex strings
        public static string PrimaryHex   => Current.Primary;
        public static string SecondaryHex => Current.Secondary;

        // ─── COLOR MATH ───────────────────────────────────────────────
        public static string LightenHex(string hex, double amount)
        {
            (double h, double s, double l) = HexToHsl(hex);
            return HslToHex(h, s, Math.Min(1, l + amount));
        }
        public static string DarkenHex(string hex, double amount)
        {
            (double h, double s, double l) = HexToHsl(hex);
            return HslToHex(h, s, Math.Max(0, l - amount * l));
        }
        public static string BlendHex(string hex1, string hex2, double t)
        {
            var c1 = ParseHex(hex1); var c2 = ParseHex(hex2);
            int r = (int)(c1.r + (c2.r - c1.r) * t);
            int g = (int)(c1.g + (c2.g - c1.g) * t);
            int b = (int)(c1.b + (c2.b - c1.b) * t);
            return $"#{r:X2}{g:X2}{b:X2}";
        }
        private static (int r, int g, int b) ParseHex(string hex)
        {
            hex = hex.TrimStart('#');
            if (hex.Length == 6)
                return (Convert.ToInt32(hex[..2], 16), Convert.ToInt32(hex[2..4], 16), Convert.ToInt32(hex[4..6], 16));
            return (128, 0, 255);
        }
        private static (double h, double s, double l) HexToHsl(string hex)
        {
            var (ri, gi, bi) = ParseHex(hex);
            double r = ri / 255.0, g = gi / 255.0, b = bi / 255.0;
            double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
            double l = (max + min) / 2.0, h = 0, s = 0;
            if (max != min)
            {
                double d = max - min;
                s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                if      (max == r) h = (g - b) / d + (g < b ? 6 : 0);
                else if (max == g) h = (b - r) / d + 2;
                else               h = (r - g) / d + 4;
                h *= 60;
            }
            return (h, s, l);
        }
    }
}
