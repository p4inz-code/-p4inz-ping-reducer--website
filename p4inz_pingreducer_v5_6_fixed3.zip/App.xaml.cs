using System;
using System.Windows;
using System.Windows.Threading;

namespace ExitLag
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Load saved theme (or default) and apply to all resources
            ThemeManager.LoadAndApply(this);

            // Global WPF exception handler — prevents crashes showing nothing
            DispatcherUnhandledException += (s, ex) =>
            {
                System.Diagnostics.Debug.WriteLine($"[p4inz] Unhandled: {ex.Exception}");
                ex.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (s, ex) =>
            {
                System.Diagnostics.Debug.WriteLine($"[p4inz] Domain: {ex.ExceptionObject}");
            };
        }
    }
}
