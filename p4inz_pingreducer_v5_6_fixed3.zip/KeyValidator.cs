using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ExitLag
{
    // ─── RESULT TYPES ────────────────────────────────────────────────────────
    public enum KeyStatus { Valid, Invalid, Expired, WrongDevice, NoInternet, WrongProduct, Revoked, DeviceTransferAllowed }

    public class KeyResult
    {
        public KeyStatus Status   { get; set; }
        public string    Message  { get; set; } = "";
        public string    Plan     { get; set; } = "";
        public string    Buyer    { get; set; } = "";
        public DateTime  Expiry   { get; set; }
        public bool      Offline  { get; set; } = false;
        public string    Key      { get; set; } = ""; // stored for transfer use
        public int       DaysLeft => Math.Max(0, (int)(Expiry - DateTime.UtcNow).TotalDays);
    }

    public static class KeyValidator
    {
        private const string DB_URL          = "https://p4inz-exitlag-default-rtdb.firebaseio.com/";
        private const string PRODUCT_ID      = "exitlag";
        private const int    OFFLINE_GRACE_H = 48;

        // Key file — persists across reinstalls/updates as long as AppData exists
        public static readonly string KeyFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "p4inz", "exitlag.key");

        // Cache file — stores last valid result for offline mode
        private static readonly string CacheFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "p4inz", "exitlag_cache.json");

        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(10) };

        // ─── DEVICE FINGERPRINT ──────────────────────────────────────────────
        public static string GetDeviceId()
        {
            try
            {
                var cpu   = GetWmi("Win32_Processor", "ProcessorId");
                var disk  = GetWmi("Win32_DiskDrive",  "SerialNumber");
                var board = GetWmi("Win32_BaseBoard",  "SerialNumber");
                var raw   = $"{cpu}|{disk}|{board}";
                using var sha = System.Security.Cryptography.SHA256.Create();
                var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(raw));
                return Convert.ToHexString(hash)[..16];
            }
            catch
            {
                var fb = $"{Environment.MachineName}{Environment.UserName}";
                return Math.Abs(fb.GetHashCode()).ToString("X16");
            }
        }

        private static string GetWmi(string cls, string prop)
        {
            try
            {
                var s = new System.Management.ManagementObjectSearcher($"SELECT {prop} FROM {cls}");
                foreach (var o in s.Get()) return o[prop]?.ToString()?.Trim() ?? "";
            }
            catch { }
            return "";
        }

        // ─── MAIN VALIDATE ───────────────────────────────────────────────────
        public static async Task<KeyResult> ValidateAsync(string key)
        {
            key = key.Trim().ToUpper();

            if (!Regex.IsMatch(key, @"^P4NZ-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$"))
                return Fail(KeyStatus.Invalid,
                    "Invalid key format.\nKeys look like: P4NZ-XXXX-XXXX-XXXX\nGet yours at discord.gg/obsidianlabs");

            try
            {
                var resp = await Http.GetStringAsync($"{DB_URL}keys/{key}.json");

                if (resp == "null" || string.IsNullOrWhiteSpace(resp))
                    return Fail(KeyStatus.Invalid,
                        "Key not found. Check you typed it correctly.\nContact p4inz on Discord if this keeps happening.");

                var data = JsonSerializer.Deserialize<JsonElement>(resp);

                // Revoked
                if (data.TryGetProperty("active", out var av) && !av.GetBoolean())
                    return Fail(KeyStatus.Revoked,
                        "This key has been revoked.\nContact p4inz on Discord for support.");

                // Wrong product
                if (data.TryGetProperty("product", out var pv))
                {
                    var prod = pv.GetString() ?? "";
                    if (!string.IsNullOrEmpty(prod) && prod != PRODUCT_ID)
                        return Fail(KeyStatus.WrongProduct,
                            $"This key is for a different p4inz tool ({prod}).\nYou need an Exit Lag key — discord.gg/obsidianlabs");
                }

                // Expiry
                string expiryStr = data.TryGetProperty("expiry", out var ev) ? ev.GetString() ?? "" : "";
                if (!DateTime.TryParse(expiryStr, null,
                    System.Globalization.DateTimeStyles.RoundtripKind, out var expiry))
                    return Fail(KeyStatus.Invalid, "Key data error. Contact p4inz on Discord.");

                if (DateTime.UtcNow > expiry)
                    return new KeyResult
                    {
                        Status  = KeyStatus.Expired,
                        Expiry  = expiry,
                        Message = $"Key expired {expiry:dd MMM yyyy}.\nRenew at discord.gg/obsidianlabs to continue."
                    };

                // HWID check
                string savedDevice = data.TryGetProperty("deviceId", out var dv) ? dv.GetString() ?? "" : "";
                string thisDevice  = GetDeviceId();

                // Check if transfer/logout was requested by user from this app
                bool transferAllowed = data.TryGetProperty("transferAllowed", out var tv) && tv.GetBoolean();

                if (string.IsNullOrEmpty(savedDevice))
                {
                    // First use — lock to this PC
                    await LockDeviceAsync(key, thisDevice);
                }
                else if (savedDevice == thisDevice)
                {
                    // Same PC — always let them in, no matter reinstall or update
                    // Clear any pending transfer flag
                    if (transferAllowed) await ClearTransferFlagAsync(key);
                }
                else
                {
                    // Different PC
                    if (transferAllowed)
                    {
                        // User logged out from old PC — transfer to this one
                        await LockDeviceAsync(key, thisDevice);
                        await ClearTransferFlagAsync(key);
                    }
                    else
                    {
                        // Blocked — but offer logout option
                        return new KeyResult
                        {
                            Status  = KeyStatus.WrongDevice,
                            Key     = key,
                            Message = "This key is logged in on another PC.\nYou can log out that device below."
                        };
                    }
                }

                string plan  = data.TryGetProperty("plan",  out var plv) ? plv.GetString() ?? "Unknown" : "Unknown";
                string buyer = data.TryGetProperty("buyer", out var bv)  ? bv.GetString()  ?? "Unknown" : "Unknown";

                var result = new KeyResult
                {
                    Status  = KeyStatus.Valid,
                    Plan    = plan,
                    Buyer   = buyer,
                    Expiry  = expiry,
                    Key     = key,
                    Offline = false,
                    Message = "OK"
                };

                _ = WriteLastSeenAsync(key);
                SaveOfflineCache(key, result);
                SaveKeyFile(key); // always keep key file fresh

                return result;
            }
            catch (HttpRequestException)  { return await OfflineFallbackAsync(key, "No internet connection."); }
            catch (TaskCanceledException) { return await OfflineFallbackAsync(key, "Server timed out."); }
            catch (Exception ex)          { return Fail(KeyStatus.Invalid, $"Unexpected error: {ex.Message}"); }
        }

        // ─── LOGOUT FROM OTHER DEVICE ────────────────────────────────────────
        // Called when user clicks "Log out other device" in the UI
        public static async Task<bool> RequestDeviceTransferAsync(string key)
        {
            try
            {
                var body = new StringContent("true", Encoding.UTF8, "application/json");
                var resp = await Http.PutAsync($"{DB_URL}keys/{key}/transferAllowed.json", body);
                return resp.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        // ─── OFFLINE FALLBACK ────────────────────────────────────────────────
        private static async Task<KeyResult> OfflineFallbackAsync(string key, string reason)
        {
            try
            {
                if (!File.Exists(CacheFile)) return NoInternet(reason);

                var raw    = await File.ReadAllTextAsync(CacheFile);
                var cached = JsonSerializer.Deserialize<CachedKey>(raw);
                if (cached == null || cached.Key != key) return NoInternet(reason);

                double hoursSince = (DateTime.UtcNow - cached.LastChecked).TotalHours;
                if (hoursSince > OFFLINE_GRACE_H)
                    return Fail(KeyStatus.NoInternet,
                        $"{reason}\nOffline cache expired ({OFFLINE_GRACE_H}h limit).\nConnect to the internet to continue.");

                if (DateTime.UtcNow > cached.Expiry)
                    return new KeyResult
                    {
                        Status  = KeyStatus.Expired,
                        Expiry  = cached.Expiry,
                        Message = $"Key expired {cached.Expiry:dd MMM yyyy}.\nRenew at discord.gg/obsidianlabs"
                    };

                return new KeyResult
                {
                    Status  = KeyStatus.Valid,
                    Plan    = cached.Plan,
                    Buyer   = cached.Buyer,
                    Expiry  = cached.Expiry,
                    Key     = key,
                    Offline = true,
                    Message = $"Offline mode — last verified {(int)hoursSince}h ago."
                };
            }
            catch { }
            return NoInternet(reason);
        }

        private static KeyResult NoInternet(string reason) =>
            Fail(KeyStatus.NoInternet, $"{reason}\nCheck your internet and try again.");

        // ─── KEY FILE (persistent across reinstalls) ─────────────────────────
        public static void SaveKeyFile(string key)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(KeyFile)!);
                File.WriteAllText(KeyFile, key);
            }
            catch { }
        }

        public static string? LoadKeyFile()
        {
            try
            {
                if (!File.Exists(KeyFile)) return null;
                var k = File.ReadAllText(KeyFile).Trim();
                return string.IsNullOrEmpty(k) ? null : k;
            }
            catch { return null; }
        }

        public static void DeleteKeyFile()
        {
            try { if (File.Exists(KeyFile)) File.Delete(KeyFile); } catch { }
        }

        // ─── OFFLINE CACHE ───────────────────────────────────────────────────
        private static void SaveOfflineCache(string key, KeyResult r)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(CacheFile)!);
                File.WriteAllText(CacheFile, JsonSerializer.Serialize(new CachedKey
                {
                    Key         = key,
                    Plan        = r.Plan,
                    Buyer       = r.Buyer,
                    Expiry      = r.Expiry,
                    LastChecked = DateTime.UtcNow
                }));
            }
            catch { }
        }

        private sealed class CachedKey
        {
            public string   Key         { get; set; } = "";
            public string   Plan        { get; set; } = "";
            public string   Buyer       { get; set; } = "";
            public DateTime Expiry      { get; set; }
            public DateTime LastChecked { get; set; }
        }

        // ─── FIREBASE WRITES ─────────────────────────────────────────────────
        private static async Task LockDeviceAsync(string key, string deviceId)
        {
            try
            {
                var body = new StringContent($"\"{deviceId}\"", Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}keys/{key}/deviceId.json", body);
            }
            catch { }
        }

        private static async Task ClearTransferFlagAsync(string key)
        {
            try
            {
                var body = new StringContent("false", Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}keys/{key}/transferAllowed.json", body);
            }
            catch { }
        }

        private static async Task WriteLastSeenAsync(string key)
        {
            try
            {
                var ts   = DateTime.UtcNow.ToString("O");
                var body = new StringContent($"\"{ts}\"", Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}keys/{key}/lastSeen.json", body);
            }
            catch { }
        }

        private static KeyResult Fail(KeyStatus s, string msg) => new() { Status = s, Message = msg };
    }
}
