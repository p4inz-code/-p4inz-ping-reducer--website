using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ExitLag
{
    // ─── GUEST SESSION DATA ───────────────────────────────────────────────────
    public class GuestData
    {
        public string   GuestId      { get; set; } = "";
        public string   Hwid         { get; set; } = "";
        public DateTime FirstSeen    { get; set; }
        public DateTime LastSeen     { get; set; }
        public int      SessionCount { get; set; }
        public string   LastGame     { get; set; } = "";
        public string   LastRegion   { get; set; } = "";
        public int      BestPing     { get; set; } = 9999;
    }

    // ─── GUEST SESSION MANAGER ────────────────────────────────────────────────
    public static class GuestSession
    {
        private const string DB_URL = "https://p4inz-exitlag-default-rtdb.firebaseio.com/";

        private static readonly string GuestFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "p4inz", "pingreducer_guest.json");

        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(8) };

        public static GuestData? Current { get; private set; }

        // ─── START GUEST SESSION ─────────────────────────────────────────────
        // Called when user clicks "Try as Guest"
        public static async Task<GuestData> StartAsync()
        {
            string hwid    = KeyValidator.GetDeviceId();
            string guestId = ComputeGuestId(hwid);

            var data = LoadLocal() ?? new GuestData
            {
                GuestId   = guestId,
                Hwid      = hwid,
                FirstSeen = DateTime.UtcNow,
            };

            data.LastSeen     = DateTime.UtcNow;
            data.SessionCount += 1;
            data.GuestId       = guestId;
            data.Hwid          = hwid;

            SaveLocal(data);
            await SyncToFirebaseAsync(data);   // awaited — suppresses CS1998, still fast

            Current = data;
            return data;
        }

        // ─── UPDATE GUEST STATS ───────────────────────────────────────────────
        // Called during session to track what they used
        public static void UpdateStats(string? game, string? region, int bestPing)
        {
            if (Current == null) return;
            if (!string.IsNullOrEmpty(game))   Current.LastGame   = game;
            if (!string.IsNullOrEmpty(region)) Current.LastRegion = region;
            if (bestPing > 0 && bestPing < Current.BestPing) Current.BestPing = bestPing;
            SaveLocal(Current);
            _ = SyncToFirebaseAsync(Current);
        }

        // ─── MIGRATE GUEST → KEY ─────────────────────────────────────────────
        // Called when a guest enters a valid key on the same device
        // Returns migration summary text to show the user
        public static async Task<string?> MigrateToKeyAsync(string key)
        {
            var data = Current ?? LoadLocal();
            if (data == null) return null;

            // Verify HWID matches — same device
            string thisHwid = KeyValidator.GetDeviceId();
            if (data.Hwid != thisHwid) return null;

            try
            {
                // Write guest history into the key's buyer record
                var payload = JsonSerializer.Serialize(new
                {
                    migratedFrom    = data.GuestId,
                    guestSessions   = data.SessionCount,
                    guestFirstSeen  = data.FirstSeen.ToString("O"),
                    guestLastGame   = data.LastGame,
                    guestBestPing   = data.BestPing,
                    migratedAt      = DateTime.UtcNow.ToString("O")
                });
                var content = new StringContent(payload, Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}keys/{key}/guestHistory.json", content);

                // Mark guest record as converted
                var conv = new StringContent($"\"{key}\"", Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}guests/{data.GuestId}/convertedToKey.json", conv);
            }
            catch { /* silent — migration is best-effort */ }

            // Build friendly summary
            string sessions = data.SessionCount == 1 ? "1 session" : $"{data.SessionCount} sessions";
            string game     = string.IsNullOrEmpty(data.LastGame) ? "—" : data.LastGame;
            string ping     = data.BestPing < 9999 ? $"{data.BestPing}ms" : "—";

            // Clean up local guest file
            DeleteLocal();
            Current = null;

            return $"Welcome! Your {sessions} as guest have been saved.\nLast game: {game}  ·  Best ping: {ping}";
        }

        // ─── GUEST LIMITATIONS ───────────────────────────────────────────────
        // Feature gate checks — all routed through here for easy future changes
        public static bool CanUseFeature(GuestFeature feature) => feature switch
        {
            GuestFeature.Connect        => true,   // yes — must see value
            GuestFeature.PingGraph      => true,   // yes — visual hook
            GuestFeature.GameProfiles   => true,   // limited to 3 games (enforced in UI)
            GuestFeature.RegionSelect   => false,  // locked to ASIA only
            GuestFeature.ExportLog      => false,
            GuestFeature.Screenshot     => false,
            GuestFeature.Leaderboard    => false,
            GuestFeature.ReportCard     => false,
            GuestFeature.DiscordRPC     => false,
            GuestFeature.GpuBoost       => false,
            GuestFeature.AntiLag        => false,
            GuestFeature.PacketPriority => false,
            GuestFeature.SmartSwitch    => false,
            GuestFeature.NeonEdge       => false,
            GuestFeature.StreamerMode   => false,
            GuestFeature.AutoDetect     => false,
            GuestFeature.Presets        => false,
            GuestFeature.IspDetector    => true,   // yes — shows them the problem we solve
            GuestFeature.SpeedTest      => true,   // yes — hook
            GuestFeature.AutoRegion     => false,
            _                           => false,
        };

        public static readonly string[] GuestGames = { "Free Fire", "BGMI", "Mobile Legends" };
        public const  string            GuestRegion = "ASIA";
        public const  int               GuestMaxSessions = 999; // unlimited guest use, just limited features

        // ─── LOCAL PERSISTENCE ────────────────────────────────────────────────
        public static GuestData? LoadLocal()
        {
            try
            {
                if (!File.Exists(GuestFile)) return null;
                var raw = File.ReadAllText(GuestFile);
                return JsonSerializer.Deserialize<GuestData>(raw);
            }
            catch { return null; }
        }

        private static void SaveLocal(GuestData data)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(GuestFile)!);
                File.WriteAllText(GuestFile, JsonSerializer.Serialize(data));
            }
            catch { }
        }

        public static void DeleteLocal()
        {
            try { if (File.Exists(GuestFile)) File.Delete(GuestFile); } catch { }
        }

        // ─── FIREBASE SYNC ────────────────────────────────────────────────────
        private static async Task SyncToFirebaseAsync(GuestData data)
        {
            try
            {
                var payload = JsonSerializer.Serialize(new
                {
                    hwid         = data.Hwid,
                    firstSeen    = data.FirstSeen.ToString("O"),
                    lastSeen     = data.LastSeen.ToString("O"),
                    sessionCount = data.SessionCount,
                    lastGame     = data.LastGame,
                    lastRegion   = data.LastRegion,
                    bestPing     = data.BestPing,
                });
                var content = new StringContent(payload, Encoding.UTF8, "application/json");
                await Http.PutAsync($"{DB_URL}guests/{data.GuestId}.json", content);
            }
            catch { }
        }

        // ─── GUEST ID COMPUTATION ─────────────────────────────────────────────
        // SHA256 of HWID → 16-char hex — stable, anonymous, unique per machine
        private static string ComputeGuestId(string hwid)
        {
            using var sha = System.Security.Cryptography.SHA256.Create();
            var bytes = System.Text.Encoding.UTF8.GetBytes("guest_" + hwid);
            var hash  = sha.ComputeHash(bytes);
            return "G-" + Convert.ToHexString(hash)[..14];
        }
    }

    // ─── FEATURE ENUM ────────────────────────────────────────────────────────
    public enum GuestFeature
    {
        Connect, PingGraph, GameProfiles, RegionSelect,
        ExportLog, Screenshot, Leaderboard, ReportCard,
        DiscordRPC, GpuBoost, AntiLag, PacketPriority,
        SmartSwitch, NeonEdge, StreamerMode, AutoDetect,
        Presets, IspDetector, SpeedTest, AutoRegion
    }
}
