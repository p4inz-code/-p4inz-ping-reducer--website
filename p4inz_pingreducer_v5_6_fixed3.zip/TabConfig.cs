using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace ExitLag
{
    // ─── SINGLE TAB DEFINITION ────────────────────────────────────────────────
    public class TabDef
    {
        public string Id        { get; set; } = "";   // internal ID, never changes
        public string Label     { get; set; } = "";   // shown in sidebar — user can rename
        public string Icon      { get; set; } = "";   // emoji icon
        public string PanelName { get; set; } = "";   // x:Name of StackPanel to show
        public bool   Visible   { get; set; } = true;
        public int    Order     { get; set; } = 0;
        public bool   Locked    { get; set; } = false; // can't be hidden (Home)
    }

    // ─── DEFAULT TAB SET ─────────────────────────────────────────────────────
    public static class TabDefaults
    {
        public static List<TabDef> Build() => new()
        {
            new() { Id = "home",     Label = "Home",     Icon = "⚡", PanelName = "PanelHome",     Visible = true,  Order = 0, Locked = true  },
            new() { Id = "games",    Label = "Games",    Icon = "🎮", PanelName = "PanelGames",    Visible = true,  Order = 1, Locked = false },
            new() { Id = "tools",    Label = "Tools",    Icon = "🛠️", PanelName = "PanelTools",    Visible = true,  Order = 2, Locked = false },
            new() { Id = "stats",    Label = "Stats",    Icon = "📊", PanelName = "PanelStats",    Visible = true,  Order = 3, Locked = false },
            new() { Id = "settings", Label = "Settings", Icon = "⚙️", PanelName = "PanelSettings", Visible = true,  Order = 4, Locked = false },
            new() { Id = "licence",  Label = "Licence",  Icon = "🔑", PanelName = "PanelLicence",  Visible = true,  Order = 5, Locked = false },
        };
    }

    // ─── ICON PRESETS ─────────────────────────────────────────────────────────
    public static class TabIcons
    {
        public static readonly string[] All =
        {
            "⚡", "🎮", "🛠️", "📊", "⚙️", "🔑", "🏠", "🎯", "🔥", "⭐",
            "💎", "🚀", "🌐", "🔒", "📡", "💻", "🎪", "🏆", "⚔️", "🌀",
            "🔵", "🟢", "🟣", "🔴", "🟡", "🎨", "💡", "🔔", "📌", "🗂️",
        };
    }

    // ─── TAB CONFIG MANAGER ───────────────────────────────────────────────────
    public static class TabConfig
    {
        private static readonly string ConfigFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "p4inz", "pingreducer_tabs.json");

        public static List<TabDef> Current { get; private set; } = TabDefaults.Build();

        public static void Load()
        {
            try
            {
                if (!File.Exists(ConfigFile)) { Current = TabDefaults.Build(); return; }
                var saved = JsonSerializer.Deserialize<List<TabDef>>(File.ReadAllText(ConfigFile));
                if (saved == null || saved.Count == 0) { Current = TabDefaults.Build(); return; }

                // Merge saved with defaults — so new tabs added in future updates appear
                var defaults = TabDefaults.Build();
                foreach (var def in defaults)
                {
                    if (!saved.Any(t => t.Id == def.Id))
                        saved.Add(def); // add new tabs that weren't in saved config
                }
                // Ensure locked tabs stay visible
                foreach (var t in saved.Where(t => t.Locked)) t.Visible = true;
                Current = saved.OrderBy(t => t.Order).ToList();
            }
            catch { Current = TabDefaults.Build(); }
        }

        public static void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(ConfigFile)!);
                File.WriteAllText(ConfigFile, JsonSerializer.Serialize(Current));
            }
            catch { }
        }

        public static void MoveUp(string id)
        {
            var tab = Current.FirstOrDefault(t => t.Id == id);
            if (tab == null) return;
            int idx = Current.IndexOf(tab);
            if (idx <= 0) return;
            Current.RemoveAt(idx);
            Current.Insert(idx - 1, tab);
            ReIndex();
            Save();
        }

        public static void MoveDown(string id)
        {
            var tab = Current.FirstOrDefault(t => t.Id == id);
            if (tab == null) return;
            int idx = Current.IndexOf(tab);
            if (idx >= Current.Count - 1) return;
            Current.RemoveAt(idx);
            Current.Insert(idx + 1, tab);
            ReIndex();
            Save();
        }

        public static void SetVisible(string id, bool visible)
        {
            var tab = Current.FirstOrDefault(t => t.Id == id);
            if (tab == null || tab.Locked) return;
            tab.Visible = visible;
            Save();
        }

        public static void SetLabel(string id, string label)
        {
            var tab = Current.FirstOrDefault(t => t.Id == id);
            if (tab == null || string.IsNullOrWhiteSpace(label)) return;
            tab.Label = label.Trim();
            Save();
        }

        public static void SetIcon(string id, string icon)
        {
            var tab = Current.FirstOrDefault(t => t.Id == id);
            if (tab == null) return;
            tab.Icon = icon;
            Save();
        }

        public static void ResetToDefaults()
        {
            Current = TabDefaults.Build();
            Save();
        }

        private static void ReIndex()
        {
            for (int i = 0; i < Current.Count; i++) Current[i].Order = i;
        }

        public static IEnumerable<TabDef> Visible => Current.Where(t => t.Visible).OrderBy(t => t.Order);
    }
}
