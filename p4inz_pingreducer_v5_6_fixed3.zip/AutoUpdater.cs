using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;

namespace ExitLag
{
    public static class AutoUpdater
    {
        private const string VERSION_URL     = "https://p4inz-exitlag-default-rtdb.firebaseio.com/updates/exitlag.json";
        public  const string CURRENT_VERSION = "4.0";
        private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(8) };

        public static async Task CheckAndPromptAsync()
        {
            try
            {
                var resp = await Http.GetStringAsync(VERSION_URL);
                if (resp == "null" || string.IsNullOrWhiteSpace(resp)) return;

                var data   = JsonSerializer.Deserialize<JsonElement>(resp);
                string latest = data.TryGetProperty("version",     out var vv) ? vv.GetString() ?? "" : "";
                string url    = data.TryGetProperty("downloadUrl", out var du) ? du.GetString() ?? "" : "";
                string notes  = data.TryGetProperty("notes",       out var nv) ? nv.GetString() ?? "" : "";

                if (string.IsNullOrEmpty(latest) || string.IsNullOrEmpty(url)) return;
                if (!IsNewer(latest)) return;

                string notesPart = string.IsNullOrEmpty(notes) ? "" : $"\n\nWhat's new:\n{notes}";
                var res = MessageBox.Show(
                    $"p4inz Exit Lag v{latest} is available!\n(You have v{CURRENT_VERSION}){notesPart}\n\nDownload now?",
                    "Update Available", MessageBoxButton.YesNo, MessageBoxImage.Information);

                if (res == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch { }
        }

        private static bool IsNewer(string latest)
        {
            try { return new Version(latest) > new Version(CURRENT_VERSION); }
            catch { return false; }
        }
    }
}
